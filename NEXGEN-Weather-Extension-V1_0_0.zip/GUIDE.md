# Customization & Publishing Guide

This guide walks through everything to personalize before shipping
NEXGEN Weather, and how to publish it to the Chrome Web Store and
Microsoft Edge Add-ons.

---

## 1. About screen and repository links

The production About screen uses the NEXGEN Weather repository and the
following repository documents:

- `PRIVACY.md`
- `TERMS-OF-SERVICE.md`
- `LICENSE.md`

The UI displays clean labels such as **Privacy Policy**, **Terms of Service**,
and **License** rather than raw `.md` filenames.

Support: `support.nexgen.devstudio@gmail.com`

Developer: `nexgen.devstudio@gmail.com`

## 2. Extension name & version

Edit `public/manifest.json`:

```json
{
  "name": "Your Extension Name",
  "short_name": "Your Short Name",
  "version": "1.0.0",
  "description": "Your one-line store description."
}
```

Also update the brand text in `src/components/Header.tsx` ("NEXGEN
Weather") and `src/dashboard/Dashboard.tsx` sidebar header if you're
renaming the product, plus the `<title>` tags in `popup.html` and
`dashboard.html`.

Bump `version` on every release — both stores require a strictly
increasing version number per upload. Also update `CHANGELOG.md`.

## 3. Icons

Replace the four PNGs in `public/icons/` (`icon16.png`, `icon32.png`,
`icon48.png`, `icon128.png`) with your own artwork at the same
dimensions and transparent background. Keep the same filenames, or
update the paths referenced in `public/manifest.json`'s `icons` and
`action.default_icon` blocks.

## 4. API key

**None needed.** This extension uses Open-Meteo, which is free and
keyless for the forecast, air-quality, and geocoding endpoints used
here (see `src/services/openMeteoApi.ts` and `geocodingApi.ts`). If you
swap in a different weather provider that requires an API key:

1. Never hardcode the key in source. Use a build-time environment
   variable (Vite exposes `import.meta.env.VITE_*` variables) or have
   users paste their own key into a Settings field, persisted via
   `chromeStorage.ts`.
2. Update `host_permissions` in `public/manifest.json` to the new API's
   domain.

## 5. Building for release

```bash
npm install
npm run build
```

Output lands in `dist/`. Zip its **contents** (not the folder itself)
for store uploads:

```bash
cd dist && zip -r ../nexgen-weather-release.zip . && cd ..
```

## 6. Publishing to the Chrome Web Store

1. Create a [Chrome Web Store developer account](https://chrome.google.com/webstore/devconsole) (one-time $5 fee).
2. **New Item** → upload `nexgen-weather-release.zip`.
3. Fill in the store listing: description, screenshots (1280×800 or
   640×400), promo tile, category (Productivity → Weather makes sense),
   and the privacy policy URL from step 1.
4. Under **Privacy practices**, disclose the `storage`, `alarms`, and
   `geolocation` permissions and justify each (e.g. geolocation is only
   used if/when you wire up auto-detect location; storage persists
   settings and saved cities; alarms schedule background refresh).
5. Submit for review. Initial review is typically a few days.

## 7. Publishing to Microsoft Edge Add-ons

1. Create a [Microsoft Partner Center](https://partner.microsoft.com/dashboard/microsoftedge/overview) account (free).
2. **Create new extension** → upload the same `nexgen-weather-release.zip`
   (Edge accepts standard Chromium MV3 packages).
3. Complete the listing (description, screenshots, privacy policy URL,
   support contact).
4. Submit for certification — typically faster than Chrome's review.

## 8. Location permissions

The production build does not request the browser's `geolocation` permission.
Users search for and select locations through Open-Meteo geocoding, and the
extension stores the selected coordinates locally.

## 9. Notifications

Notifications are optional and use the Manifest V3 `notifications` and
`alarms` APIs. The notification icon is referenced as a relative packaged
resource (`icons/icon128.png`), which is the supported format for
`chrome.notifications.create()`.

The Settings screen supports 15 minutes, 30 minutes, 1 hour, Custom (1–1440
minutes), and Manual Only.

Before publishing, test from the built extension's Settings screen and verify
that Windows/Brave/Chrome notifications are allowed.

## 10. Store screenshots

Both stores want 1280×800 (or 640×400) screenshots. The dashboard view
(`dashboard.html`) at a wide viewport tends to make for a more
impressive store listing than the 400×640 popup alone — capture both.
