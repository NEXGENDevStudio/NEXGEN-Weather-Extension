import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'node:path'

// Manifest V3 extension build.
// Every runtime page is a real Vite HTML entry so its JS/CSS is bundled into
// dist/. In particular, sidepanel.html must NOT be copied as an unbuilt source
// page: Chrome/Brave loads the packaged HTML from dist and cannot resolve a
// /src/... module from there.
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': resolve(import.meta.dirname, 'src')
    }
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    target: 'es2020',
    rollupOptions: {
      input: {
        popup: resolve(import.meta.dirname, 'popup.html'),
        dashboard: resolve(import.meta.dirname, 'dashboard.html'),
        sidepanel: resolve(import.meta.dirname, 'sidepanel.html'),
        'service-worker': resolve(import.meta.dirname, 'src/background/service-worker.ts')
      },
      output: {
        entryFileNames: (chunk) =>
          chunk.name === 'service-worker'
            ? 'background/service-worker.js'
            : 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]'
      }
    }
  }
})
