// Final production-package sanity check.
import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const dist = resolve(process.cwd(), 'dist')
const required = [
  'manifest.json',
  'popup.html',
  'dashboard.html',
  'sidepanel.html',
  'background/service-worker.js',
  'icons/icon16.png',
  'icons/icon32.png',
  'icons/icon48.png',
  'icons/icon128.png'
]

let ok = true
for (const file of required) {
  if (!existsSync(resolve(dist, file))) {
    console.error(`[postbuild] Missing expected output: ${file}`)
    ok = false
  }
}

try {
  const manifest = JSON.parse(readFileSync(resolve(dist, 'manifest.json'), 'utf8'))
  const expected = {
    version: '1.0.0',
    popup: 'popup.html',
    sidePanel: 'sidepanel.html',
    serviceWorker: 'background/service-worker.js'
  }

  if (manifest.version !== expected.version) {
    console.error(`[postbuild] Unexpected manifest version: ${manifest.version}`)
    ok = false
  }
  if (manifest.action?.default_popup !== expected.popup) {
    console.error('[postbuild] action.default_popup is incorrect.')
    ok = false
  }
  if (manifest.side_panel?.default_path !== expected.sidePanel) {
    console.error('[postbuild] side_panel.default_path is incorrect.')
    ok = false
  }
  if (manifest.background?.service_worker !== expected.serviceWorker) {
    console.error('[postbuild] background.service_worker is incorrect.')
    ok = false
  }
} catch (error) {
  console.error('[postbuild] Could not validate manifest.json:', error)
  ok = false
}

if (!ok) process.exit(1)
console.log('[postbuild] Production extension package verified — ready for Load unpacked / store packaging.')
