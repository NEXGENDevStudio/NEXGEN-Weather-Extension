import { access, readFile } from 'node:fs/promises'

const required = [
  'dist/manifest.json',
  'dist/popup.html',
  'dist/dashboard.html',
  'dist/sidepanel.html',
  'dist/background/service-worker.js',
  'dist/icons/icon16.png',
  'dist/icons/icon32.png',
  'dist/icons/icon48.png',
  'dist/icons/icon128.png'
]

for (const file of required) await access(file)

const manifest = JSON.parse(await readFile('dist/manifest.json', 'utf8'))
if (manifest.version !== '1.0.0') throw new Error(`Expected version 1.0.0, got ${manifest.version}`)
if (manifest.side_panel?.default_path !== 'sidepanel.html') throw new Error('Invalid side panel path')
if (manifest.background?.service_worker !== 'background/service-worker.js') throw new Error('Invalid service worker path')

// A built extension page must reference bundled assets, never source files.
const sidepanel = await readFile('dist/sidepanel.html', 'utf8')
if (sidepanel.includes('/src/')) throw new Error('sidepanel.html still references source files')

console.log('OK: production extension package is structurally valid.')
