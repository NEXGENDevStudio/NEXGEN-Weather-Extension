# NEXGEN Weather — Premium Weather Browser Extension

A production-ready, Windows 11 Fluent-inspired weather extension for
Chromium browsers (Chrome, Edge, Brave, Opera). Built with React, Vite,
TypeScript and Tailwind CSS, using Manifest V3.

![theme](https://img.shields.io/badge/manifest-v3-4fc3f7) ![stack](https://img.shields.io/badge/stack-React%20%2B%20Vite%20%2B%20TS-8ecae6)

## Highlights

- **Glassmorphic UI** — frosted-glass cards, backdrop blur, soft shadows,
  Fluent-style rounded corners throughout.
- **Dynamic animated backgrounds** — the popup and dashboard scene
  (gradient sky, drifting clouds, falling rain/snow, fog bands, twinkling
  stars, lightning flashes) automatically match current conditions.
- **Full weather picture** — current conditions, feels-like, humidity,
  wind, pressure, visibility, UV index, AQI, dew point, sunrise/sunset,
  hourly forecast, and a 7-day outlook.
- **Two surfaces** — a compact popup (matches the reference design) and
  a full-screen dashboard with a sidebar for a more spacious view.
- **Search, favorites & multiple locations**, backed by `chrome.storage`.
- **Light / Dark / Auto themes**, °C/°F toggle, configurable auto-refresh,
  and a notifications switch.
- **Powered by [Open-Meteo](https://open-meteo.com)** — free, keyless,
  no request quota for personal use.
- No unnecessary dependencies, no tracking, no ads.

## Project Structure

```
nexgen-weather-extension/
├─ public/
│  ├─ manifest.json        # MV3 manifest
│  └─ icons/                # extension icons (16/32/48/128)
├─ src/
│  ├─ popup/                 # popup.html entry (Popup.tsx + main.tsx)
│  ├─ dashboard/              # dashboard.html entry (Dashboard.tsx + main.tsx)
│  ├─ background/              # MV3 service worker
│  ├─ components/               # shared, reusable UI pieces
│  ├─ pages/                     # screen-level views (Search, Hourly, 7-Day, Settings, About)
│  ├─ services/                    # Open-Meteo + geocoding API clients, WMO code mapping
│  ├─ storage/                      # chrome.storage wrappers (settings, locations)
│  ├─ hooks/                         # useWeather, useSettings, useTheme, useLocations
│  ├─ types/                          # shared TypeScript types
│  ├─ utils/                           # formatters
│  └─ styles/                           # Tailwind entry + animation keyframes
├─ popup.html
├─ dashboard.html
├─ vite.config.ts
└─ tailwind.config.js
```

## Getting Started

### Prerequisites

- Node.js 18+ and npm

### Install & Build

```bash
npm install
npm run build
```

This produces a `dist/` folder containing everything needed to load as
an unpacked extension: `manifest.json`, `popup.html`, `dashboard.html`,
`background/service-worker.js`, hashed asset bundles, and icons.

### Load into Chrome / Edge / Brave

1. Run `npm run build`.
2. Open `chrome://extensions` (or `edge://extensions`, `brave://extensions`).
3. Enable **Developer mode**.
4. Click **Load unpacked** and select the `dist/` folder.
5. Pin the NEXGEN Weather icon to your toolbar.

### Local development

```bash
npm run dev
```

Vite's dev server is useful for iterating on styles/components in a
regular browser tab, but `chrome.*` APIs (storage, tabs) only work once
loaded as an actual extension — see `src/storage/chromeStorage.ts` for
the in-memory fallback used outside the extension context.

## Before You Ship

Read **[GUIDE.md](./GUIDE.md)** for:
- Replacing the `{{PLACEHOLDER}}` values on the About screen
- Renaming the extension / bumping the version
- Swapping in your own icons
- Publishing to the Chrome Web Store and Microsoft Edge Add-ons

## Documentation

- [GUIDE.md](./GUIDE.md) — customization & publishing walkthrough
- [CHANGELOG.md](./CHANGELOG.md) — version history
- [LICENSE.md](./LICENSE.md) — proprietary license
- [PRIVACY.md](./PRIVACY.md) — privacy policy
- [TERMS-OF-SERVICE.md](./TERMS-OF-SERVICE.md) — terms of service

## Weather Data

Weather and forecast data come from the [Open-Meteo](https://open-meteo.com)
forecast, air-quality, and geocoding APIs — all free and keyless. No API
key setup is required.

## Browser Support

Google Chrome · Microsoft Edge · Brave · Opera · other Chromium-based
browsers supporting Manifest V3.

## License

Proprietary — see [LICENSE.md](./LICENSE.md).
