import { fetchWeatherSnapshot } from '@/services/openMeteoApi'
import { getExtremeTemperatureAdvisory, getWeatherLabel } from '@/services/weatherCodeMap'
import { formatTemperature } from '@/utils/formatters'
import { loadSettings } from '@/storage/settingsStore'
import { loadActiveLocationId, loadLocations } from '@/storage/locationsStore'
import { storageGet, storageSet } from '@/storage/chromeStorage'

const ALARM_NAME = 'nexgen-weather-notify'
const SETTINGS_KEY = 'nexgen.settings'
const MIN_PERIOD_MINUTES = 1

async function ensureAlarmFromSettings(): Promise<void> {
  const settings = await loadSettings()
  await syncAlarm(settings.notificationsEnabled, settings.refreshInterval)
}

chrome.runtime.onInstalled.addListener(() => {
  ensureAlarmFromSettings().catch((error) => console.error('[NEXGEN Weather] Alarm setup failed:', error))
})

chrome.runtime.onStartup?.addListener(() => {
  ensureAlarmFromSettings().catch((error) => console.error('[NEXGEN Weather] Alarm restore failed:', error))
})

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes[SETTINGS_KEY]) return
  // Always reload the complete settings object. Do not depend on a partial
  // storage change payload containing both notification fields.
  ensureAlarmFromSettings().catch((error) => console.error('[NEXGEN Weather] Alarm sync failed:', error))
})

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== ALARM_NAME) return
  checkWeatherAndNotify(false).catch((error) => console.error('[NEXGEN Weather] Scheduled check failed:', error))
})

chrome.runtime.onMessage.addListener((message: { type?: string }, _sender, sendResponse) => {
  if (message?.type === 'TEST_NOTIFICATION') {
    createNotification(
      'NEXGEN Weather',
      'Test notification — your weather notifications are working.',
      'nexgen-weather-test'
    ).then(sendResponse)
    return true
  }

  if (message?.type === 'REFRESH_NOW') {
    checkWeatherAndNotify(true).then(sendResponse)
    return true
  }

  return false
})

async function syncAlarm(notificationsEnabled: boolean, refreshInterval: number): Promise<void> {
  await chrome.alarms.clear(ALARM_NAME)

  if (!notificationsEnabled || refreshInterval <= 0) return

  // Chrome alarms are the supported MV3 mechanism for periodic work. A
  // one-minute interval is the minimum exposed by this extension.
  const periodInMinutes = Math.max(MIN_PERIOD_MINUTES, Math.round(refreshInterval))
  await chrome.alarms.create(ALARM_NAME, {
    delayInMinutes: periodInMinutes,
    periodInMinutes
  })

  const alarm = await chrome.alarms.get(ALARM_NAME)
  if (!alarm) {
    throw new Error('Chrome did not create the weather notification alarm.')
  }
}

async function getActiveLocation() {
  const [locations, activeId] = await Promise.all([loadLocations(), loadActiveLocationId()])
  return locations.find((l) => l.id === activeId) ?? locations.find((l) => l.isFavorite) ?? locations[0]
}

async function checkWeatherAndNotify(force: boolean): Promise<{ ok: boolean; error?: string }> {
  try {
    const settings = await loadSettings()
    if (!force && (!settings.notificationsEnabled || settings.refreshInterval <= 0)) {
      return { ok: false, error: 'Notifications are turned off or set to Manual Only.' }
    }

    const location = await getActiveLocation()
    if (!location) return { ok: false, error: 'No location is set yet.' }

    const snapshot = await fetchWeatherSnapshot(location)
    const { current } = snapshot
    const unitLetter = settings.temperatureUnit === 'fahrenheit' ? 'F' : 'C'
    const tempLabel = `${formatTemperature(current.temperature, settings.temperatureUnit)}°${unitLetter}`
    const feelsLikeLabel = `${formatTemperature(current.feelsLike, settings.temperatureUnit)}°${unitLetter}`
    const advisory = getExtremeTemperatureAdvisory(current.temperature)
    const conditionLabel = advisory ? advisory.label : getWeatherLabel(current.weatherCode)
    const thirdLine = advisory ? advisory.advisory : `Feels like ${feelsLikeLabel}`
    const message = `${location.name}\n${tempLabel} — ${conditionLabel}\n${thirdLine}`

    return createNotification('NEXGEN Weather', message, 'nexgen-weather-update')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Weather check failed.'
    console.error('[NEXGEN Weather] Weather check failed:', error)
    return { ok: false, error: force ? message : undefined }
  }
}

const NOTIFICATION_ICON_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAFs0lEQVR4nO2dy3IbRRiF/1HpEfwEke1EFy9sNqwBJ5Biw4LseASSEMwljrHlxDFLIPAGXoRLUbwA8AaWZHylyoEdK71Ds0g6NRpLmunpy9+X86mmyk7k6Zn/nDnT01LPZG8e/EcWETZXnhCZrRU3hTCqEQS3Q7GuxgzRNCQZhHeLrLe2EZqGNgTwoG2EugkA4f2ithGaQl1LiO8vghRNoJoAEN9/lExQtQ8A4cOi8imhSgJA/HApTYNmib4QP3zmmqBpdhwIhEZjzv/BGvEwU8tZfQCIHx9TTwXT+gAQP16umMDUZwEgUJoF/WGH+JlIASRA4uSvAmCFdHitdZMwEJA0MgHggvQQRBgJTJ55I4EgAdAHSJwG4fyfMgLjAIlTHAkEiYE+QOLgKiBxgu0DHL71VaX3vfHnE8tbEjbZ2g//BmGBqoKXAUNMkq1+/4/XBhi8vW1lvWt/PLay3tDw1gC2hC+SuhEaJIh8W1yJT/SqLQ/2mWvJVp/5kwCDd9wJP42139NLA28SgFt8olfb4EEtXC4NQfyvwTq/+JLB+jZ7PVy+2BNguL7jQFY1hus77Eemq4V1JHB40z/xJT5vm0nYEiCEAg9vxp8EZbODQeT1aQhB5HoZ3upz73dlhrf6zuvjcnHeBxi923fdpDYhbnNVgv000DmR1qnhsscxeq/vaLfM83Lb3dXK1YIEUCHCWjVceW10e9fVPlljdHvXg2PW7IIEUCWyemEcQJm46oUEUCWyejkZBzh6P57P2WPaFyLMDq5FTDXDvIDEwcygOkRUMyRA4uAqoA4R1Qyzg2sQU83QB6hDRDXTfWoYmMLxw+vjsvesfP33gottKQN9gDpMqdnxZrnoE+/PmWRln88MWe/phRMLHH+w56IZ66z8tjXxu6rwc9fNYATTj46NHlmvk0c3jAkvkWbqPb1wZgSMA9TAhvgu158HfQAV2gfjk0dumpIm6O3ZTQNnCdD71VHlbNE+cHZU5jnZspsGbmcGhQqT+JKTrRtjW5o47QR2f9mk0w/37TaiKtb5R15cj5dhS6fwB4J0j87i3xcNwXz0S0632+Pu43PjZs06/TPn4Xx6RzMFPBGFg+6uWROwXAZ2f96s94ftg3HK4tugIYQgjkUZCE9ERKc77bFJHdgGgjo/Paz2Rhz1Vzjrd4zVg/UWMZ0fS0wA4WdjSAP2oeCZJoD4Tmiw36FACOo8/3JyqyB+KWe7nbGJ2jubHFq2tKUJIH5lTNTdrw+DIL4aBrRj7wNIzp90Ib4iJmqGL4WGjqZ+XiTA+V4PRz8TmBwaOLr6eZEAgA/2q4CLfcS/Fpr64RYxwaOnH3sCAE10EwD6h42ufkiA0EEfIHXQB0iW61/8pf39QPZxABM7AeqDkcCAMaEd+gCBsvz5kZHkZH9sHAmi5c/M7ExSGKo9ex8A8OJFApAgWt5AClRleeNowVgCcD+6NP9a2hjBBCUsbYwWTNbcmwSQy9KnMMFcDNfbyz4ATDAdG3XxLgFeJ8EDmCDP0oORsfO+9wkggQnsk7XuDwT3RlTh8pvVZL85tPjJ0NqB4HUC5LFZhCptc7Vvu92sdS+MBMhz+a2bNFi8P734Ltqf1bZpgjRAHtNiVC28TRO4Ep+IKGvdPQzaAEUuv1tTEmbx3kCr2Krt2dyWOmTXIjMAFy80jNBiEF6SXfv4kOjlVSEwxItn5WZo3eUTPUcGA6RNhtnBiRPMOACwg/xOYEY4DaRGRoQESJ58HwApkA6Z/AEJkDjFmUFIgfjJ8r9gdnDiTJsbiBSIl6z4D7NmBsEE8XFFfKL5s4NhgniYKj4RrgKSp2x2MFIgfGYe/UTVZgfDBOEyV3yi6ncIkSuCEcKgVHiJah+g8ooBG0oa1blHEE4J/qJ8gDZFPS1xSvCL2smse5cwGIEX7VOyqWcHwwhuMdYXM32fwOKGwRBmsNb5/h+piuImoPvLsAAAAABJRU5ErkJggg=='

function createNotification(
  title: string,
  message: string,
  idPrefix: string
): Promise<{ ok: boolean; error?: string }> {
  return new Promise((resolve) => {
    if (!chrome.notifications?.create) {
      resolve({ ok: false, error: 'Chrome Notifications API is unavailable.' })
      return
    }

    chrome.notifications.getPermissionLevel((level) => {
      const permissionError = chrome.runtime.lastError
      if (permissionError) {
        resolve({ ok: false, error: permissionError.message || 'Could not read notification permission.' })
        return
      }
      if (level !== 'granted') {
        resolve({
          ok: false,
          error: 'Chrome notification permission is denied. Allow notifications for Chrome in Windows settings, then reload the extension.'
        })
        return
      }

      try {
        chrome.notifications.create(
          `${idPrefix}-${Date.now()}`,
          {
            type: 'basic',
            // Use a self-contained data URL. This avoids the Chromium/Brave
            // image-loader failure seen with extension-resource icon URLs in
            // some MV3 service-worker contexts ("Unable to download all
            // specified images"). Chrome officially permits data URLs here.
            iconUrl: NOTIFICATION_ICON_URL,
            title,
            message,
            priority: 2
          },
          (notificationId) => {
            const lastError = chrome.runtime.lastError
            if (lastError) {
              resolve({ ok: false, error: lastError.message || 'Chrome rejected the notification.' })
              return
            }
            resolve(
              notificationId
                ? { ok: true }
                : { ok: false, error: 'Chrome did not return a notification ID.' }
            )
          }
        )
      } catch (error) {
        resolve({
          ok: false,
          error: error instanceof Error ? error.message : 'Notification creation failed.'
        })
      }
    })
  })
}
