import { useState } from 'react'
import { useSettings } from '@/hooks/useSettings'
import { useTheme } from '@/hooks/useTheme'
import { useLocations } from '@/hooks/useLocations'
import { useWeather } from '@/hooks/useWeather'
import { getWeatherCondition } from '@/services/weatherCodeMap'
import { AnimatedBackground } from '@/components/AnimatedBackground'
import { Header } from '@/components/Header'
import { MenuDropdown } from '@/components/MenuDropdown'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import { ToastHost, showToast } from '@/components/Toast'
import { requestTestNotification } from '@/services/runtimeMessaging'
import { WeatherView } from '@/pages/WeatherView'
import { SearchView } from '@/pages/SearchView'
import { HourlyView } from '@/pages/HourlyView'
import { SevenDayView } from '@/pages/SevenDayView'
import { SettingsView } from '@/pages/SettingsView'
import { AboutView } from '@/pages/AboutView'
import type { AppSettings } from '@/types/settings'
import type { SavedLocation } from '@/types/weather'
import type { PopupView } from '@/popup/Popup'

/**
 * The Side Panel mirrors Popup's composition exactly — same hooks, same
 * pages, same components — so it shows the same weather experience Popup
 * does, instead of a separate simplified view. Settings/locations are
 * backed by chrome.storage (see useSettings/useLocations), so unit,
 * theme and location changes made in Popup/Dashboard reach this panel
 * immediately, and vice versa, with no reload required.
 */
export function SidePanel() {
  const { settings, updateSettings, loaded: settingsLoaded } = useSettings()
  const { locations, activeLocation, loaded: locationsLoaded, addLocation, removeLocation, toggleFavorite } =
    useLocations()
  const { snapshot, isLoading, error, refresh } = useWeather(activeLocation, settings.refreshInterval)
  const [view, setView] = useState<PopupView>('weather')
  const [menuOpen, setMenuOpen] = useState(false)

  useTheme(settings.theme)

  const condition = snapshot
    ? getWeatherCondition(snapshot.current.weatherCode, snapshot.current.isDay)
    : 'clear-day'

  const handleSelectLocation = async (loc: SavedLocation) => {
    await addLocation(loc)
    setView('weather')
  }

  const handleSettingsUpdate = (patch: Partial<AppSettings>) => {
    if (patch.temperatureUnit && patch.temperatureUnit !== settings.temperatureUnit) {
      showToast(`Temperature unit changed to °${patch.temperatureUnit === 'fahrenheit' ? 'F' : 'C'}`)
    }
    updateSettings(patch)
  }

  const handleTestNotification = async () => {
    const result = await requestTestNotification()
    showToast(result.ok ? 'Test notification sent' : result.error ?? 'Notification failed')
    return result
  }

  const handleOpenDashboard = () => {
    setMenuOpen(false)
    if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') })
    } else {
      window.open('/dashboard.html', '_blank')
    }
  }

  if (!settingsLoaded || !locationsLoaded) {
    return (
      <div className="sidepanel-root rounded-xl2 relative flex items-center justify-center overflow-hidden">
        <LoadingSpinner size={28} />
      </div>
    )
  }

  return (
    <div className="sidepanel-root rounded-xl2 relative flex flex-col overflow-hidden">
      <AnimatedBackground condition={condition} />

      <div className="relative z-10 flex-1 flex flex-col overflow-hidden">
        {view === 'weather' && (
          <>
            <Header
              locationLabel={activeLocation ? `${activeLocation.name}, ${activeLocation.country}` : 'Loading…'}
              isFavorite={!!activeLocation?.isFavorite}
              isRefreshing={isLoading}
              onLocationClick={() => setView('search')}
              onFavoriteToggle={() => activeLocation && toggleFavorite(activeLocation.id)}
              onRefresh={refresh}
              onMenuClick={() => setMenuOpen((o) => !o)}
            />
            <WeatherView snapshot={snapshot} isLoading={isLoading} error={error} settings={settings} />
          </>
        )}

        {view === 'search' && (
          <SearchView
            savedLocations={locations}
            activeId={activeLocation?.id}
            onBack={() => setView('weather')}
            onSelect={handleSelectLocation}
            onToggleFavorite={toggleFavorite}
            onRemove={removeLocation}
          />
        )}

        {view === 'hourly' && (
          <HourlyView snapshot={snapshot} unit={settings.temperatureUnit} onBack={() => setView('weather')} />
        )}

        {view === 'sevenday' && (
          <SevenDayView snapshot={snapshot} unit={settings.temperatureUnit} onBack={() => setView('weather')} />
        )}

        {view === 'settings' && (
          <SettingsView
            settings={settings}
            locations={locations}
            onBack={() => setView('weather')}
            onUpdate={handleSettingsUpdate}
            onManageLocations={() => setView('search')}
            onTestNotification={handleTestNotification}
          />
        )}

        {view === 'about' && <AboutView onBack={() => setView('weather')} />}
      </div>

      {menuOpen && (
        <MenuDropdown
          onNavigate={(v) => {
            setView(v)
            setMenuOpen(false)
          }}
          onOpenDashboard={handleOpenDashboard}
          onClose={() => setMenuOpen(false)}
        />
      )}

      <ToastHost />
    </div>
  )
}
