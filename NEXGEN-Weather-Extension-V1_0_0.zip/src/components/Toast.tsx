import { useEffect, useState } from 'react'
import { CheckIcon } from './Icons'

interface ToastMessage {
  id: number
  text: string
}

let pushToast: ((text: string) => void) | null = null

/** Fire-and-forget helper — call from anywhere without prop-drilling setters. */
export function showToast(text: string) {
  pushToast?.(text)
}

/**
 * Renders transient, non-blocking confirmation toasts (e.g. "Temperature
 * unit changed to °C"). Mount once near the root of each surface
 * (Popup / Dashboard). Auto-dismisses via the `toastOut` CSS animation;
 * the JS timeout below just unmounts the node afterwards.
 */
export function ToastHost() {
  const [toasts, setToasts] = useState<ToastMessage[]>([])

  useEffect(() => {
    pushToast = (text: string) => {
      const id = Date.now() + Math.random()
      setToasts((prev) => [...prev, { id, text }])
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id))
      }, 4000)
    }
    return () => {
      pushToast = null
    }
  }, [])

  if (toasts.length === 0) return null

  return (
    <div className="toast" role="status" aria-live="polite">
      <CheckIcon size={14} className="text-[var(--link-color)] shrink-0 mt-0.5" />
      <span>{toasts[toasts.length - 1].text}</span>
    </div>
  )
}
