import type { ReactNode } from 'react'
import { ArrowLeftIcon, CloseIcon } from './Icons'

interface Props {
  title: string
  onBack: () => void
  onClose?: () => void
  right?: ReactNode
}

/** "← Title" bar used at the top of Search / Hourly / 7-Day / Settings / About. */
export function ScreenHeader({ title, onBack, onClose, right }: Props) {
  return (
    <div className="flex items-center justify-between px-4 pt-3 pb-2">
      <button type="button" onClick={onBack} className="nav-back-btn" aria-label="Go back">
        <ArrowLeftIcon size={17} />
      </button>
      <h2 className="text-[15px] font-semibold">{title}</h2>
      <div className="w-8 h-8 flex items-center justify-center">
        {right ?? (onClose && (
          <button type="button" onClick={onClose} className="nav-back-btn" aria-label="Close">
            <CloseIcon size={16} />
          </button>
        ))}
      </div>
    </div>
  )
}
