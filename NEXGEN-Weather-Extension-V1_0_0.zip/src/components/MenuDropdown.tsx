import { useEffect, useRef } from 'react'
import {
  BellIcon,
  ChevronRightIcon,
  ExpandIcon,
  InfoIcon,
  SearchIcon,
  SettingsIcon,
  StarIcon
} from './Icons'
import type { PopupView } from '@/popup/Popup'

interface Props {
  onNavigate: (view: PopupView) => void
  onOpenDashboard: () => void
  /** Omit when this menu is already rendered inside the Side Panel itself. */
  onOpenSidePanel?: () => void
  onClose: () => void
}

const items: { view: PopupView; label: string; icon: JSX.Element }[] = [
  { view: 'search', label: 'Search Location', icon: <SearchIcon size={16} /> },
  { view: 'hourly', label: 'Hourly Forecast', icon: <BellIcon size={16} /> },
  { view: 'sevenday', label: '7-Day Forecast', icon: <StarIcon size={16} /> },
  { view: 'settings', label: 'Settings', icon: <SettingsIcon size={16} /> },
  { view: 'about', label: 'About', icon: <InfoIcon size={16} /> }
]

/** Popover menu triggered by the hamburger icon in the main Header. */
export function MenuDropdown({ onNavigate, onOpenDashboard, onOpenSidePanel, onClose }: Props) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose()
    }
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('mousedown', handleClick)
    document.addEventListener('keydown', handleKey)
    return () => {
      document.removeEventListener('mousedown', handleClick)
      document.removeEventListener('keydown', handleKey)
    }
  }, [onClose])

  return (
    <div
      ref={ref}
      role="menu"
      aria-label="Navigation menu"
      className="glass-panel absolute right-4 top-14 z-30 w-56 rounded-xl2 py-2 shadow-glass animate-scaleIn origin-top-right"
    >
      {items.map((item) => (
        <button
          key={item.view}
          type="button"
          role="menuitem"
          onClick={() => onNavigate(item.view)}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 text-[13px] hover:bg-[var(--hover-overlay)] transition-colors"
        >
          <span className="opacity-90">{item.icon}</span>
          <span className="flex-1 text-left">{item.label}</span>
          <ChevronRightIcon size={14} className="opacity-50" />
        </button>
      ))}
      <div className="hairline-divider my-1.5 mx-3.5" />
      {onOpenSidePanel && (
        <button
          type="button"
          role="menuitem"
          onClick={onOpenSidePanel}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 text-[13px] hover:bg-[var(--hover-overlay)] transition-colors"
        >
          <span className="opacity-90"><ExpandIcon size={16} /></span>
          <span className="flex-1 text-left">Pin Weather to Side Panel</span>
        </button>
      )}
      <button
        type="button"
        role="menuitem"
        onClick={onOpenDashboard}
        className="w-full flex items-center gap-3 px-3.5 py-2.5 text-[13px] hover:bg-[var(--hover-overlay)] transition-colors"
      >
        <span className="opacity-90"><ExpandIcon size={16} /></span>
        <span className="flex-1 text-left">Open Full Dashboard</span>
      </button>
    </div>
  )
}
