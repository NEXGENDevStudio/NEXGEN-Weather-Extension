export function LoadingSpinner({ size = 28 }: { size?: number }) {
  return (
    <div
      className="animate-spin rounded-full border-2"
      style={{
        width: size,
        height: size,
        borderColor: 'var(--divider-color)',
        borderTopColor: 'var(--text-primary)'
      }}
      role="status"
      aria-label="Loading"
    />
  )
}
