import type { ReactNode } from 'react'

interface Props {
  icon: ReactNode
  label: string
  value: string
  sublabel?: string
}

/** Compact icon + label + value tile, used in the metrics grid. */
export function MetricTile({ icon, label, value, sublabel }: Props) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="shrink-0 opacity-90">{icon}</div>
      <div className="min-w-0">
        <div className="text-[11px] leading-tight text-[var(--text-secondary)]">{label}</div>
        <div className="text-sm font-semibold leading-tight truncate">{value}</div>
        {sublabel && <div className="text-[10px] text-[var(--text-tertiary)] leading-tight">{sublabel}</div>}
      </div>
    </div>
  )
}
