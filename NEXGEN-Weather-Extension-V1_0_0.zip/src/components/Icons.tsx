interface IconProps {
  size?: number
  className?: string
  strokeWidth?: number
}

/**
 * Minimal hand-rolled line-icon set. Keeping these inline avoids pulling
 * in an icon library just for ~20 glyphs, which matters for a
 * "small bundle, minimal permissions" browser extension.
 */
const base = (size = 18, strokeWidth = 1.8) => ({
  width: size,
  height: size,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const
})

export const ArrowLeftIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}><path d="M19 12H5M12 19l-7-7 7-7" /></svg>
)
export const CloseIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}><path d="M18 6 6 18M6 6l12 12" /></svg>
)
export const ChevronDownIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}><path d="m6 9 6 6 6-6" /></svg>
)
export const ChevronRightIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}><path d="m9 18 6-6-6-6" /></svg>
)
export const StarIcon = ({ size, className, strokeWidth, filled }: IconProps & { filled?: boolean }) => (
  <svg {...base(size, strokeWidth)} className={className} fill={filled ? 'currentColor' : 'none'}>
    <path d="m12 3 2.9 6.3 6.6.6-5 4.7 1.5 6.6L12 17.9 6 21.2l1.5-6.6-5-4.7 6.6-.6L12 3Z" />
  </svg>
)
export const RefreshIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M21 12a9 9 0 1 1-2.6-6.4M21 4v5h-5" />
  </svg>
)
export const MenuIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}><path d="M4 7h16M4 12h16M4 17h16" /></svg>
)
export const SearchIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
  </svg>
)
export const MapPinIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" /><circle cx="12" cy="10" r="3" />
  </svg>
)
export const DropletIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M12 2s7 7.5 7 12.5A7 7 0 0 1 5 14.5C5 9.5 12 2 12 2Z" />
  </svg>
)
export const WindIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M3 8h11a3 3 0 1 0-3-3M3 16h14a3 3 0 1 1-3 3M3 12h9" />
  </svg>
)
export const GaugeIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M4 14a8 8 0 1 1 16 0" /><path d="M12 14 16 9" /><path d="M4 14h16" />
  </svg>
)
export const EyeIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M1.5 12S5 5 12 5s10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12Z" /><circle cx="12" cy="12" r="3" />
  </svg>
)
export const SunIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <circle cx="12" cy="12" r="4.5" />
    <path d="M12 2v2.5M12 19.5V22M4.2 4.2l1.8 1.8M18 18l1.8 1.8M2 12h2.5M19.5 12H22M4.2 19.8 6 18M18 6l1.8-1.8" />
  </svg>
)
export const SunriseIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M12 17V9M8.5 12.5 12 9l3.5 3.5" /><path d="M4 17h16M6 20h12" />
  </svg>
)
export const SunsetIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M12 9v8M8.5 13.5 12 17l3.5-3.5" /><path d="M4 17h16M6 20h12" />
  </svg>
)
export const LeafIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M20 4S9 3 5.5 9 7 20 7 20 18 21 20 12c1-4.5-.5-8-0.5-8Z" />
    <path d="M7 20 18 4" />
  </svg>
)
export const ThermometerIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M14 14.76V4a2 2 0 1 0-4 0v10.76a4 4 0 1 0 4 0Z" />
  </svg>
)
export const BellIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M6 8a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6Z" /><path d="M9.5 19a2.5 2.5 0 0 0 5 0" />
  </svg>
)
export const TrashIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" />
  </svg>
)
export const SettingsIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" />
  </svg>
)
export const InfoIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <circle cx="12" cy="12" r="10" /><path d="M12 11v6M12 7.5v.01" />
  </svg>
)
export const CheckIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}><path d="m5 12 5 5 9-9" /></svg>
)
export const ExpandIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" />
  </svg>
)
export const CloudIcon = ({ size, className, strokeWidth }: IconProps) => (
  <svg {...base(size, strokeWidth)} className={className}>
    <path d="M7 18a4 4 0 1 1 .7-7.94A5.5 5.5 0 0 1 18 12.5 3.5 3.5 0 0 1 17.5 19H7Z" />
  </svg>
)
