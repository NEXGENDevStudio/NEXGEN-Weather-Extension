import { CloudIcon, MapPinIcon, MenuIcon, RefreshIcon, StarIcon, ChevronDownIcon } from './Icons'
import { RippleButton } from './RippleButton'

interface Props {
  locationLabel: string
  isFavorite: boolean
  isRefreshing: boolean
  onLocationClick: () => void
  onFavoriteToggle: () => void
  onRefresh: () => void
  onMenuClick: () => void
}

/** Single-row top bar: brand mark, location pill, and quick actions. */
export function Header({
  locationLabel,
  isFavorite,
  isRefreshing,
  onLocationClick,
  onFavoriteToggle,
  onRefresh,
  onMenuClick
}: Props) {
  return (
    <div className="flex items-center justify-between gap-2 px-4 pt-2.5 pb-2">
      <div className="flex items-center gap-1.5 shrink-0">
        <div className="w-6 h-6 rounded-full bg-[var(--chip-bg)] flex items-center justify-center">
          <CloudIcon size={13} />
        </div>
        <span className="font-semibold text-[14px] tracking-tight">NEXGEN</span>
        <span className="hidden sm:inline text-[13px] text-[var(--text-secondary)]">Weather</span>
      </div>

      <button
        type="button"
        onClick={onLocationClick}
        className="flex items-center gap-1 min-w-0 px-2 py-1 rounded-full hover:bg-[var(--hover-overlay)] transition-colors"
      >
        <MapPinIcon size={13} className="text-[var(--text-secondary)] shrink-0" />
        <span className="truncate max-w-[150px] text-[13px] font-medium">{locationLabel}</span>
        <ChevronDownIcon size={13} className="text-[var(--text-secondary)] shrink-0" />
      </button>

      <div className="flex items-center gap-0.5 shrink-0">
        <RippleButton onClick={onFavoriteToggle} className="icon-btn w-8 h-8" aria-label="Toggle favorite">
          <StarIcon size={16} filled={isFavorite} />
        </RippleButton>
        <RippleButton onClick={onRefresh} className="icon-btn w-8 h-8" aria-label="Refresh weather">
          <RefreshIcon size={16} className={isRefreshing ? 'animate-spin' : ''} />
        </RippleButton>
        <RippleButton onClick={onMenuClick} className="icon-btn w-8 h-8" aria-label="Open menu">
          <MenuIcon size={16} />
        </RippleButton>
      </div>
    </div>
  )
}
