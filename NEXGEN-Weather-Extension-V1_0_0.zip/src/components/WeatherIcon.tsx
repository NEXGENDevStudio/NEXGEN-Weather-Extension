import type { WeatherCondition } from '@/types/weather'

interface Props {
  condition: WeatherCondition
  size?: number
  className?: string
}

export function WeatherIcon({ condition, size = 48, className = '' }: Props) {
  const common = { width: size, height: size, viewBox: '0 0 64 64', className, 'aria-hidden': true }

  switch (condition) {
    case 'clear-day':
      return (
        <svg {...common}>
          <circle cx="32" cy="32" r="12" fill="#FFD166" />
          {Array.from({ length: 8 }).map((_, i) => {
            const angle = (i * Math.PI) / 4
            const x1 = 32 + Math.cos(angle) * 18
            const y1 = 32 + Math.sin(angle) * 18
            const x2 = 32 + Math.cos(angle) * 24
            const y2 = 32 + Math.sin(angle) * 24
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#FFD166" strokeWidth="2.5" strokeLinecap="round" />
          })}
        </svg>
      )
    case 'clear-night':
      return (
        <svg {...common}>
          <path d="M40 13c-7 3-12 10-12 18 0 11 8 19 19 19 3 0 6-.7 8.5-2-3.2 5-8.8 8-15 8C29 56 20 47 20 35c0-11 8-20 20-22z" fill="#DCE5F4" />
          <circle cx="45" cy="19" r="1.4" fill="#FFFFFF" opacity=".85" />
          <circle cx="49" cy="27" r="1" fill="#FFFFFF" opacity=".75" />
        </svg>
      )
    case 'partly-cloudy-day':
      return (
        <svg {...common}>
          <circle cx="23" cy="23" r="9" fill="#FFD166" />
          {Array.from({ length: 6 }).map((_, i) => {
            const angle = (i * Math.PI) / 3
            return <line key={i} x1={23 + Math.cos(angle) * 12} y1={23 + Math.sin(angle) * 12} x2={23 + Math.cos(angle) * 15} y2={23 + Math.sin(angle) * 15} stroke="#FFD166" strokeWidth="2" strokeLinecap="round" />
          })}
          <path d="M19 47h27c7 0 11-4 11-9s-4-9-10-9c-2-7-7-10-13-10-7 0-12 4-14 10-5 0-9 4-9 9s3 9 8 9z" fill="#DCE3EA" stroke="#B8C4D0" strokeWidth="1.5" />
        </svg>
      )
    case 'partly-cloudy-night':
      return (
        <svg {...common}>
          <path d="M28 13c-4 2-7 6-7 11 0 7 5 12 12 12 2 0 4-.4 5.5-1.2-2.2 3.8-6.3 6.2-11 6.2-7.2 0-13-5.8-13-13 0-6.5 4.7-12 11-13z" fill="#DCE5F4" />
          <path d="M22 48h26c7 0 10-4 10-9s-4-9-9-9c-2-6-7-9-12-9-4 0-7 1.5-9.5 4.3 4 2.4 6.5 6.5 6.5 11.2 0 5.2-2.8 9.6-7 12.5z" fill="#C8D2DE" stroke="#AAB8C6" strokeWidth="1.5" />
        </svg>
      )
    case 'cloudy':
      return (
        <svg {...common}>
          <path d="M14 47h35c7 0 11-4 11-9s-4-10-10-10c-2-7-7-11-14-11-7 0-12 4-14 10-5 0-9 4-9 10s4 10 9 10z" fill="#D5DDE6" stroke="#AEBBC8" strokeWidth="1.5" />
          <path d="M17 36c2-4 5-6 9-6" fill="none" stroke="#EEF2F6" strokeWidth="3" strokeLinecap="round" opacity=".9" />
        </svg>
      )
    case 'fog':
      return (
        <svg {...common}>
          <path d="M18 29c2-5 7-8 13-8 6 0 11 3 13 8" fill="none" stroke="#B8C4CF" strokeWidth="3" strokeLinecap="round" />
          {[36, 44, 52].map((y, i) => <line key={i} x1={12 + i * 3} y1={y} x2={52 - i * 3} y2={y} stroke="#AEBBC7" strokeWidth="3" strokeLinecap="round" />)}
        </svg>
      )
    case 'drizzle':
    case 'rain':
      return (
        <svg {...common}>
          <path d="M14 35h35c6 0 10-4 10-9s-4-9-9-9c-2-6-7-9-13-9-6 0-11 3-13 9-5 0-9 4-9 9s4 9 9 9z" fill="#D4DDE6" stroke="#AEBBC8" strokeWidth="1.5" />
          {[20, 32, 44].map((x, i) => <line key={i} x1={x} y1="42" x2={x - 4} y2="53" stroke="#5FA8E0" strokeWidth="3" strokeLinecap="round" />)}
        </svg>
      )
    case 'thunderstorm':
      return (
        <svg {...common}>
          <path d="M14 34h35c6 0 10-4 10-9s-4-9-9-9c-2-6-7-9-13-9-6 0-11 3-13 9-5 0-9 4-9 9s4 9 9 9z" fill="#AEB8C5" stroke="#8E9AA8" strokeWidth="1.5" />
          <polygon points="34,33 25,49 31,49 27,60 41,41 34,41 39,33" fill="#FFD166" />
        </svg>
      )
    case 'snow':
      return (
        <svg {...common}>
          <path d="M14 34h35c6 0 10-4 10-9s-4-9-9-9c-2-6-7-9-13-9-6 0-11 3-13 9-5 0-9 4-9 9s4 9 9 9z" fill="#DCE5EE" stroke="#B4C2CF" strokeWidth="1.5" />
          {[20, 32, 44].map((x, i) => (
            <g key={i} transform={`translate(${x},48)`} stroke="#8CC8EE" strokeWidth="2.2" strokeLinecap="round">
              <line x1="-4" y1="0" x2="4" y2="0" /><line x1="0" y1="-4" x2="0" y2="4" /><line x1="-3" y1="-3" x2="3" y2="3" /><line x1="-3" y1="3" x2="3" y2="-3" />
            </g>
          ))}
        </svg>
      )
    default:
      return <WeatherIcon condition="clear-day" size={size} className={className} />
  }
}
