import { useState, type ButtonHTMLAttributes, type MouseEvent } from 'react'

interface RippleDot {
  id: number
  x: number
  y: number
  size: number
}

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
}

/** Button wrapper that adds a lightweight Fluent-style ripple on click. */
export function RippleButton({ children, className = '', onClick, type = 'button', ...rest }: Props) {
  const [ripples, setRipples] = useState<RippleDot[]>([])

  const handleClick = (e: MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const size = Math.max(rect.width, rect.height)
    const dot: RippleDot = {
      id: Date.now(),
      x: e.clientX - rect.left - size / 2,
      y: e.clientY - rect.top - size / 2,
      size
    }
    setRipples((prev) => [...prev, dot])
    window.setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== dot.id))
    }, 650)
    onClick?.(e)
  }

  return (
    <button type={type} className={`ripple-surface ${className}`} onClick={handleClick} {...rest}>
      {children}
      {ripples.map((r) => (
        <span
          key={r.id}
          className="ripple-dot"
          style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
        />
      ))}
    </button>
  )
}
