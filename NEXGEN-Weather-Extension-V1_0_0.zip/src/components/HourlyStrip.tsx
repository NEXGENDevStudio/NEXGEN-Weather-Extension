import { useCallback, useEffect, useRef, useState } from 'react'
import type { ChangeEvent, KeyboardEvent, WheelEvent } from 'react'
import type { HourlyPoint, TemperatureUnit } from '@/types/weather'
import { getWeatherCondition } from '@/services/weatherCodeMap'
import { formatHour, formatTemperature } from '@/utils/formatters'
import { WeatherIcon } from './WeatherIcon'

interface Props {
  hours: HourlyPoint[]
  unit: TemperatureUnit
  limit?: number
}

/** How far an arrow-key press scrolls the strip, in pixels. Roughly one card + gap. */
const KEY_SCROLL_STEP = 52

/** Resolution of the slider's own 0..N range — arbitrary, just needs enough
 *  steps for a smooth drag. Gets mapped onto the strip's real scroll distance. */
const SLIDER_RESOLUTION = 1000

function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
  const el = e.currentTarget
  if (e.key === 'ArrowRight') {
    el.scrollBy({ left: KEY_SCROLL_STEP, behavior: 'smooth' })
    e.preventDefault()
  } else if (e.key === 'ArrowLeft') {
    el.scrollBy({ left: -KEY_SCROLL_STEP, behavior: 'smooth' })
    e.preventDefault()
  }
}

/**
 * Stops a plain vertical mouse-wheel gesture from escaping the strip and
 * scrolling the Popup/Side Panel/Dashboard underneath it — the earlier
 * "convert wheel-to-horizontal" approach still let that vertical movement
 * leak through on some inputs. The slider below is now the reliable way to
 * move through all 12 hours; native trackpad horizontal gestures (shift-
 * scroll, two-finger horizontal swipe) already work on their own via
 * `overflow-x-auto` and are left completely untouched here.
 */
function handleWheel(e: WheelEvent<HTMLDivElement>) {
  const el = e.currentTarget
  if (el.scrollWidth <= el.clientWidth) return
  if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
    e.preventDefault()
  }
}

/** Compact horizontal strip: "Now, 2 PM, 3 PM…" used in the popup weather view. */
export function HourlyStrip({ hours, unit, limit = 12 }: Props) {
  const items = hours.slice(0, limit)
  const stripRef = useRef<HTMLDivElement>(null)
  const [sliderValue, setSliderValue] = useState(0)
  const [showSlider, setShowSlider] = useState(false)

  const syncFromScroll = useCallback(() => {
    const el = stripRef.current
    if (!el) return
    const max = el.scrollWidth - el.clientWidth
    setShowSlider(max > 1)
    setSliderValue(max > 0 ? Math.round((el.scrollLeft / max) * SLIDER_RESOLUTION) : 0)
  }, [])

  // Keep the slider in sync with the strip's actual size — the strip can
  // change width (Popup vs Side Panel vs Dashboard) or grow new hours
  // without a remount, and the slider's thumb needs to reflect both.
  useEffect(() => {
    const el = stripRef.current
    syncFromScroll()
    if (!el || typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver(syncFromScroll)
    ro.observe(el)
    return () => ro.disconnect()
  }, [syncFromScroll, items.length])

  const handleSliderChange = (e: ChangeEvent<HTMLInputElement>) => {
    const el = stripRef.current
    if (!el) return
    const value = Number(e.target.value)
    const max = el.scrollWidth - el.clientWidth
    el.scrollLeft = (value / SLIDER_RESOLUTION) * max
    setSliderValue(value)
  }

  return (
    <div className="flex flex-col gap-2">
      <div
        ref={stripRef}
        id="hourly-forecast-strip"
        className="flex gap-4 overflow-x-auto pb-1 px-4 -mx-0 scrollbar-none"
        onWheel={handleWheel}
        onScroll={syncFromScroll}
        onKeyDown={handleKeyDown}
        tabIndex={0}
        role="list"
        aria-label="Hourly forecast"
      >
        {items.map((h, i) => (
          <div key={h.time} className="flex flex-col items-center gap-1.5 shrink-0 w-9" role="listitem">
            <span className={`text-[11px] ${i === 0 ? 'text-[var(--link-color)] font-medium' : 'text-[var(--text-secondary)]'}`}>
              {i === 0 ? 'Now' : formatHour(h.time)}
            </span>
            <WeatherIcon condition={getWeatherCondition(h.weatherCode, h.isDay)} size={26} />
            <span className="text-[13px] font-semibold">{formatTemperature(h.temperature, unit)}</span>
          </div>
        ))}
      </div>

      {showSlider && (
        <input
          type="range"
          className="hourly-slider mx-4"
          min={0}
          max={SLIDER_RESOLUTION}
          value={sliderValue}
          onChange={handleSliderChange}
          aria-label="Scroll hourly forecast"
          aria-controls="hourly-forecast-strip"
        />
      )}
    </div>
  )
}
