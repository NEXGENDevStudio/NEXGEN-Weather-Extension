import type { HTMLAttributes, ReactNode } from 'react'

interface Props extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode
  className?: string
  delay?: number
}

/** Standard frosted-glass container used across every screen. */
export function GlassCard({ children, className = '', delay = 0, style, ...rest }: Props) {
  return (
    <div
      className={`glass-card rounded-card animate-slideUp ${className}`}
      style={{ animationDelay: `${delay}ms`, ...style }}
      {...rest}
    >
      {children}
    </div>
  )
}
