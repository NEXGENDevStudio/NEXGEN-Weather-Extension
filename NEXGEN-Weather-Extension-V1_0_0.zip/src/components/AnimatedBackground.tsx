import { useMemo } from 'react'
import type { WeatherCondition } from '@/types/weather'

interface Props {
  condition: WeatherCondition
}

/**
 * Renders the full-bleed animated scene behind the weather content.
 * Composition is driven entirely by CSS classes/keyframes defined in
 * styles/animations.css — this component only decides which decorative
 * layers (clouds/rain/snow/fog/stars/lightning) apply to each condition.
 */
export function AnimatedBackground({ condition }: Props) {
  const isNight = condition.includes('night')
  const stars = useMemo(
    () =>
      isNight
        ? Array.from({ length: 22 }).map((_, i) => ({
            id: i,
            top: Math.random() * 55,
            left: Math.random() * 100,
            delay: Math.random() * 3
          }))
        : [],
    [isNight]
  )

  const showClouds = ['partly-cloudy-day', 'partly-cloudy-night', 'cloudy', 'rain', 'drizzle', 'thunderstorm', 'snow'].includes(
    condition
  )
  const showRain = condition === 'rain' || condition === 'drizzle'
  const showSnow = condition === 'snow'
  const showFog = condition === 'fog'
  const showStorm = condition === 'thunderstorm'
  const showCelestial = condition === 'clear-day' || condition === 'clear-night' || condition === 'partly-cloudy-day' || condition === 'partly-cloudy-night'

  return (
    <div className={`weather-scene scene-${condition}`} aria-hidden="true">
      {stars.map((star) => (
        <span
          key={star.id}
          className="star"
          style={{ top: `${star.top}%`, left: `${star.left}%`, animationDelay: `${star.delay}s` }}
        />
      ))}

      {showCelestial && (
        <div
          className={`celestial ${isNight ? 'moon' : 'sun'}`}
          style={{ width: 90, height: 90, top: 28, right: 36 }}
        />
      )}

      {showClouds && (
        <>
          <div className="cloud cloud-drift" style={{ width: 120, height: 40, top: 60, animationDuration: '32s' }} />
          <div className="cloud cloud-drift" style={{ width: 90, height: 30, top: 120, animationDuration: '24s', animationDelay: '-6s' }} />
          <div className="cloud cloud-drift" style={{ width: 150, height: 46, top: 20, animationDuration: '40s', animationDelay: '-14s' }} />
        </>
      )}

      {showFog && (
        <>
          <div className="fog-band" style={{ top: 40, animationDuration: '20s' }} />
          <div className="fog-band" style={{ top: 90, animationDuration: '26s', animationDelay: '-8s' }} />
          <div className="fog-band" style={{ top: 140, animationDuration: '16s', animationDelay: '-3s' }} />
        </>
      )}

      {showRain && <div className="rain-layer" />}
      {showSnow && <div className="snow-layer" />}
      {showStorm && (
        <>
          <div className="rain-layer" style={{ opacity: 0.35 }} />
          <div className="lightning-flash" />
        </>
      )}
    </div>
  )
}
