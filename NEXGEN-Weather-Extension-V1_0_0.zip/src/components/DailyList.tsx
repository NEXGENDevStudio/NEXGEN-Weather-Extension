import { useEffect, useMemo, useRef, useState } from 'react'
import type { DailyPoint, HourlyPoint, TemperatureUnit } from '@/types/weather'
import { getWeatherCondition, getWeatherLabel } from '@/services/weatherCodeMap'
import { formatClock, formatFullDate, formatTemperature, formatWeekday } from '@/utils/formatters'
import { WeatherIcon } from './WeatherIcon'

interface Props {
  days: DailyPoint[]
  unit: TemperatureUnit
  /** Hides the condition-label column and tightens spacing for narrow surfaces (the popup). */
  compact?: boolean
  /**
   * The same snapshot's hourly points. When provided, the selected-detail
   * tooltip resolves the hovered position to the closest *actual* hourly
   * reading for that day (real temperature, condition and timestamp)
   * instead of only interpolating a temperature.
   */
  hourly?: HourlyPoint[]
}

/**
 * 7-day forecast list.
 *
 * Uses a fixed CSS grid template (not flex) so every row's day name,
 * icon, low/high temperature, and range bar line up in identical
 * columns regardless of how much text a given row has — this is what
 * previously caused the visual misalignment. `min-w-0` on the bar
 * track is what stops the flexible column from blowing out the grid's
 * width and causing horizontal overflow.
 */
/** Which row's range bar is currently hovered/touched, and where along it. */
interface HoverState {
  dayIndex: number
  /** 0–1 fraction across the bar track, used to interpolate a temperature. */
  fraction: number
}

export function DailyList({ days, unit, compact = false, hourly }: Props) {
  const [hover, setHover] = useState<HoverState | null>(null)
  const trackRefs = useRef<Array<HTMLDivElement | null>>([])
  const tooltipRefs = useRef<Array<HTMLDivElement | null>>([])

  // Group the shared hourly forecast by calendar date so the tooltip can
  // look up real readings for whichever day is hovered, without fetching
  // anything new.
  const hourlyByDate = useMemo(() => {
    const map = new Map<string, HourlyPoint[]>()
    for (const h of hourly ?? []) {
      const date = h.time.slice(0, 10)
      const bucket = map.get(date)
      if (bucket) bucket.push(h)
      else map.set(date, [h])
    }
    return map
  }, [hourly])

  // Keep the hovered/selected day's detail panel on screen. Depends only on
  // *which* row is hovered (not the cursor fraction within it), so moving
  // the cursor across one row's bar doesn't repeatedly nudge the scroll —
  // it only adjusts, gently, when the selection moves to a new day.
  useEffect(() => {
    if (hover == null) return
    tooltipRefs.current[hover.dayIndex]?.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' })
  }, [hover?.dayIndex])

  if (days.length === 0) return null

  const highest = Math.max(...days.map((d) => d.tempMax))
  const lowest = Math.min(...days.map((d) => d.tempMin))
  const span = Math.max(highest - lowest, 1)

  const gridCols = compact
    ? 'grid-cols-[44px_24px_minmax(0,1fr)_32px]'
    : 'grid-cols-[44px_26px_minmax(0,120px)_minmax(0,1fr)_32px]'

  const updateHoverFromClientX = (dayIndex: number, clientX: number) => {
    const track = trackRefs.current[dayIndex]
    if (!track) return
    const rect = track.getBoundingClientRect()
    if (rect.width <= 0) return
    const fraction = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width))
    setHover({ dayIndex, fraction })
  }

  return (
    <div className="flex flex-col divide-y divide-[var(--divider-color)]">
      {days.map((day, i) => {
        const left = ((day.tempMin - lowest) / span) * 100
        const width = Math.max(((day.tempMax - day.tempMin) / span) * 100, 10)
        const condition = getWeatherCondition(day.weatherCode, true)

        // Interpolate a temperature under the cursor along [tempMin, tempMax]
        // so hovering any point on the bar — not just the two end labels —
        // shows a value + the day's condition.
        const isHovered = hover?.dayIndex === i
        const hoveredCelsius = isHovered
          ? day.tempMin + hover!.fraction * (day.tempMax - day.tempMin)
          : null

        // Resolve the hovered point to the closest real hourly reading for
        // this day, if we have one, so the tooltip shows an actual
        // temperature/condition/time instead of a purely interpolated value.
        const dayHours = hourlyByDate.get(day.date)
        const matchedHour =
          isHovered && hoveredCelsius !== null && dayHours && dayHours.length > 0
            ? dayHours.reduce((best, h) =>
                Math.abs(h.temperature - hoveredCelsius) < Math.abs(best.temperature - hoveredCelsius) ? h : best
              )
            : null

        return (
          <div
            key={day.date}
            className={`grid ${gridCols} items-center gap-x-2.5 py-2.5 min-w-0`}
          >
            {/* Day name */}
            <span className="text-[13px] font-medium whitespace-nowrap truncate">
              {formatWeekday(day.date, i)}
            </span>

            {/* Icon — fixed box so it never shifts row to row */}
            <span className="flex items-center justify-center shrink-0">
              <WeatherIcon condition={condition} size={compact ? 20 : 24} />
            </span>

            {/* Condition label — dashboard/wide view only */}
            {!compact && (
              <span className="text-[12px] text-[var(--text-secondary)] truncate min-w-0">
                {getWeatherLabel(day.weatherCode)}
              </span>
            )}

            {/* Low temp + range bar + high temp, grouped so they share one flexible track */}
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-[12px] tabular-nums text-[var(--text-tertiary)] w-8 text-right shrink-0">
                {formatTemperature(day.tempMin, unit)}
              </span>
              <div
                ref={(el) => (trackRefs.current[i] = el)}
                className="relative flex-1 min-w-[36px] h-3 flex items-center cursor-crosshair"
                onMouseMove={(e) => updateHoverFromClientX(i, e.clientX)}
                onMouseLeave={() => setHover((h) => (h?.dayIndex === i ? null : h))}
                onTouchStart={(e) => updateHoverFromClientX(i, e.touches[0].clientX)}
                onTouchMove={(e) => updateHoverFromClientX(i, e.touches[0].clientX)}
                onTouchEnd={() => setHover((h) => (h?.dayIndex === i ? null : h))}
              >
                <div className="relative w-full h-1.5 rounded-full bg-[var(--track-bg)] overflow-hidden">
                  <div
                    className="absolute inset-y-0 rounded-full bg-gradient-to-r from-accent-soft to-accent"
                    style={{ left: `${left}%`, width: `${width}%` }}
                  />
                </div>

                {isHovered && hoveredCelsius !== null && (
                  <>
                    {/* Marker dot at the cursor position on the bar */}
                    <div
                      className="absolute top-1/2 w-2 h-2 rounded-full bg-white ring-2 ring-[var(--link-color)] -translate-x-1/2 -translate-y-1/2 pointer-events-none"
                      style={{
                        left: `${Math.min(88, Math.max(12, hover!.fraction * 100))}%`
                      }}
                    />
                    {/* Tooltip bubble showing temp + condition + date + time.
                        Rendered BELOW the bar (not above) so it can never be
                        clipped above the top of a scrollable list — the
                        scrollIntoView effect above handles the case where it
                        would otherwise spill below the visible area. */}
                    <div
                      ref={(el) => (tooltipRefs.current[i] = el)}
                      className="absolute top-full mt-1.5 -translate-x-1/2 whitespace-nowrap rounded-md bg-[var(--tooltip-bg,#1f1f24)] text-white text-[11px] leading-tight px-2 py-1 shadow-lg pointer-events-none z-10"
                      style={{
                        left: `${Math.min(88, Math.max(12, hover!.fraction * 100))}%`
                      }}
                    >
                      <div className="font-semibold tabular-nums">
                        {formatTemperature(matchedHour ? matchedHour.temperature : hoveredCelsius, unit)}
                        {unit === 'fahrenheit' ? 'F' : 'C'}
                      </div>
                      <div className="text-white/70">
                        {getWeatherLabel(matchedHour ? matchedHour.weatherCode : day.weatherCode)} ·{' '}
                        {formatFullDate(day.date)}
                        {matchedHour ? ` · ${formatClock(matchedHour.time)}` : ''}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* High temp */}
            <span className="text-[13px] tabular-nums font-semibold w-8 text-right shrink-0 justify-self-end">
              {formatTemperature(day.tempMax, unit)}
            </span>
          </div>
        )
      })}
    </div>
  )
}
