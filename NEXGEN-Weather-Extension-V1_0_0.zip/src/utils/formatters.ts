import type { TemperatureUnit } from '@/types/weather'

/** Converts a Celsius value to the display unit and rounds to whole degrees. */
export function formatTemperature(celsius: number, unit: TemperatureUnit): string {
  const value = unit === 'fahrenheit' ? celsius * 1.8 + 32 : celsius
  return `${Math.round(value)}°`
}

export function convertTemperature(celsius: number, unit: TemperatureUnit): number {
  return unit === 'fahrenheit' ? celsius * 1.8 + 32 : celsius
}

export function formatWind(kmh: number): string {
  return `${Math.round(kmh)} km/h`
}

export function formatPercent(value: number): string {
  return `${Math.round(value)}%`
}

export function formatHour(iso: string): string {
  const date = new Date(iso)
  return date.toLocaleTimeString(undefined, { hour: 'numeric' })
}

export function formatClock(iso: string): string {
  const date = new Date(iso)
  return date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
}

export function formatWeekday(iso: string, index: number): string {
  if (index === 0) return 'Today'
  const date = new Date(iso)
  return date.toLocaleDateString(undefined, { weekday: 'short' })
}

/** e.g. "26 Aug 2026" — used in the 7-day forecast's selected-detail display. */
export function formatFullDate(iso: string): string {
  const date = new Date(iso)
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
}

export function formatLastUpdated(iso: string): string {
  return new Date(iso).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
}
