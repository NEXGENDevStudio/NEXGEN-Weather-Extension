import { useState } from 'react'
import { useSettings } from '@/hooks/useSettings'
import { useTheme } from '@/hooks/useTheme'
import { useLocations } from '@/hooks/useLocations'
import { useWeather } from '@/hooks/useWeather'
import { getWeatherCondition, getWeatherLabel, getAqiLabel, getUvLabel } from '@/services/weatherCodeMap'
import { formatClock, formatLastUpdated, formatPercent, formatTemperature, formatWind } from '@/utils/formatters'
import { AnimatedBackground } from '@/components/AnimatedBackground'
import { WeatherIcon } from '@/components/WeatherIcon'
import { GlassCard } from '@/components/GlassCard'
import { HourlyStrip } from '@/components/HourlyStrip'
import { DailyList } from '@/components/DailyList'
import { MetricTile } from '@/components/MetricTile'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import { ToastHost, showToast } from '@/components/Toast'
import { requestTestNotification } from '@/services/runtimeMessaging'
import { SearchView } from '@/pages/SearchView'
import { SettingsView } from '@/pages/SettingsView'
import { AboutView } from '@/pages/AboutView'
import {
  CloudIcon,
  DropletIcon,
  EyeIcon,
  GaugeIcon,
  InfoIcon,
  LeafIcon,
  MapPinIcon,
  RefreshIcon,
  SettingsIcon,
  SunIcon,
  SunriseIcon,
  SunsetIcon,
  ThermometerIcon,
  WindIcon
} from '@/components/Icons'
import { RippleButton } from '@/components/RippleButton'
import type { AppSettings } from '@/types/settings'
import type { SavedLocation } from '@/types/weather'

type Section = 'overview' | 'locations' | 'settings' | 'about'

export function Dashboard() {
  const { settings, updateSettings, loaded: settingsLoaded } = useSettings()
  const { locations, activeLocation, loaded: locationsLoaded, selectLocation, addLocation, removeLocation, toggleFavorite } =
    useLocations()
  const { snapshot, isLoading, error, refresh } = useWeather(activeLocation, settings.refreshInterval)
  const [section, setSection] = useState<Section>('overview')

  useTheme(settings.theme)

  const condition = snapshot
    ? getWeatherCondition(snapshot.current.weatherCode, snapshot.current.isDay)
    : 'clear-day'

  const handleSelect = async (loc: SavedLocation) => {
    await addLocation(loc)
    setSection('overview')
  }

  const handleSettingsUpdate = (patch: Partial<AppSettings>) => {
    if (patch.temperatureUnit && patch.temperatureUnit !== settings.temperatureUnit) {
      showToast(`Temperature unit changed to °${patch.temperatureUnit === 'fahrenheit' ? 'F' : 'C'}`)
    }
    updateSettings(patch)
  }

  const handleTestNotification = async () => {
    const result = await requestTestNotification()
    showToast(result.ok ? 'Test notification sent' : result.error ?? 'Notification failed')
    return result
  }

  if (!settingsLoaded || !locationsLoaded) {
    return (
      <div className="w-full h-screen flex items-center justify-center bg-white dark:bg-slate-800">
        <LoadingSpinner size={32} />
      </div>
    )
  }

  return (
    <div className="dashboard-shell relative w-[calc(100vw-28px)] min-h-[calc(100vh-28px)] m-3 flex overflow-hidden">
      <AnimatedBackground condition={condition} />

      {/* Sidebar */}
      <aside className="relative z-10 w-60 shrink-0 glass-panel border-r border-[var(--glass-panel-border)] flex flex-col p-4 gap-1">
        <div className="flex items-center gap-2 px-2 py-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-[var(--chip-bg)] flex items-center justify-center">
            <CloudIcon size={16} />
          </div>
          <div>
            <div className="font-semibold text-[15px] leading-none">NEXGEN</div>
            <div className="text-[11px] text-[var(--text-secondary)] leading-none mt-0.5">Weather Dashboard</div>
          </div>
        </div>

        <NavItem label="Overview" icon={<CloudIcon size={17} />} active={section === 'overview'} onClick={() => setSection('overview')} />
        <NavItem label="Locations" icon={<MapPinIcon size={17} />} active={section === 'locations'} onClick={() => setSection('locations')} />
        <NavItem label="Settings" icon={<SettingsIcon size={17} />} active={section === 'settings'} onClick={() => setSection('settings')} />
        <NavItem label="About" icon={<InfoIcon size={17} />} active={section === 'about'} onClick={() => setSection('about')} />

        <div className="flex-1" />

        {activeLocation && (
          <div className="glass-card rounded-card p-3 text-[12px]">
            <div className="font-medium truncate">{activeLocation.name}</div>
            <div className="text-[var(--text-tertiary)] truncate">{activeLocation.country}</div>
          </div>
        )}
      </aside>

      {/* Main content */}
      <main className="dashboard-main relative z-10 flex-1 overflow-y-auto">
        {section === 'overview' && (
          <OverviewSection
            snapshot={snapshot}
            isLoading={isLoading}
            error={error}
            unit={settings.temperatureUnit}
            onRefresh={refresh}
          />
        )}

        {section === 'locations' && (
          <div className="max-w-md mx-auto glass-panel rounded-xl2 overflow-hidden" style={{ height: '80vh' }}>
            <SearchView
              savedLocations={locations}
              activeId={activeLocation?.id}
              onBack={() => setSection('overview')}
              onSelect={handleSelect}
              onToggleFavorite={toggleFavorite}
              onRemove={removeLocation}
            />
          </div>
        )}

        {section === 'settings' && (
          <div className="max-w-md mx-auto glass-panel rounded-xl2 overflow-hidden" style={{ height: '80vh' }}>
            <SettingsView
              settings={settings}
              locations={locations}
              onBack={() => setSection('overview')}
              onUpdate={handleSettingsUpdate}
              onManageLocations={() => setSection('locations')}
              onTestNotification={handleTestNotification}
            />
          </div>
        )}

        {section === 'about' && (
          <div className="max-w-md mx-auto glass-panel rounded-xl2 overflow-hidden" style={{ height: '80vh' }}>
            <AboutView onBack={() => setSection('overview')} />
          </div>
        )}
      </main>

      <ToastHost />
    </div>
  )
}

function NavItem({ label, icon, active, onClick }: { label: string; icon: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? 'page' : undefined}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-[13px] transition-colors ${
        active ? 'bg-[var(--active-overlay)] font-medium' : 'hover:bg-[var(--hover-overlay)] text-[var(--text-secondary)]'
      }`}
    >
      {icon}
      {label}
    </button>
  )
}

function OverviewSection({
  snapshot,
  isLoading,
  error,
  unit,
  onRefresh
}: {
  snapshot: ReturnType<typeof useWeather>['snapshot']
  isLoading: boolean
  error: string | null
  unit: 'celsius' | 'fahrenheit'
  onRefresh: () => void
}) {
  if (!snapshot && isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <LoadingSpinner size={36} />
      </div>
    )
  }
  if (!snapshot) {
    return (
      <div className="h-full flex items-center justify-center text-[var(--text-secondary)]">
        {error ?? 'No weather data available.'}
      </div>
    )
  }

  const { current, hourly, daily } = snapshot
  const condition = getWeatherCondition(current.weatherCode, current.isDay)

  return (
    <div className="max-w-5xl mx-auto flex flex-col gap-6 animate-fadeIn">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-semibold">{snapshot.location.name}</h1>
          <p className="text-[var(--text-secondary)] text-sm">{snapshot.location.country}</p>
        </div>
        <RippleButton onClick={onRefresh} className="icon-btn glass-card w-10 h-10 rounded-full">
          <RefreshIcon size={18} className={isLoading ? 'animate-spin' : ''} />
        </RippleButton>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hero card */}
        <GlassCard className="lg:col-span-2 p-8 flex items-center justify-between">
          <div>
            <div className="flex items-start gap-1">
              <span className="text-[96px] leading-none font-thin tracking-tighter">
                {formatTemperature(current.temperature, unit).replace('°', '')}
              </span>
              <span className="text-4xl font-light mt-3">°{unit === 'fahrenheit' ? 'F' : 'C'}</span>
            </div>
            <p className="text-2xl font-medium mt-2">{getWeatherLabel(current.weatherCode)}</p>
            <p className="text-[var(--text-secondary)] mt-1">
              Feels like {formatTemperature(current.feelsLike, unit)}
            </p>
          </div>
          <WeatherIcon condition={condition} size={160} className="animate-floatY drop-shadow-2xl" />
        </GlassCard>

        {/* Metrics */}
        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold mb-4">Details</h3>
          <div className="grid grid-cols-2 gap-y-4 gap-x-3">
            <MetricTile icon={<DropletIcon size={17} />} label="Humidity" value={formatPercent(current.humidity)} />
            <MetricTile icon={<WindIcon size={17} />} label="Wind" value={formatWind(current.windSpeed)} />
            <MetricTile icon={<GaugeIcon size={17} />} label="Pressure" value={`${Math.round(current.pressure)} hPa`} />
            <MetricTile icon={<EyeIcon size={17} />} label="Visibility" value={`${current.visibility} km`} />
            <MetricTile icon={<SunIcon size={17} />} label="UV Index" value={getUvLabel(current.uvIndex)} />
            <MetricTile icon={<LeafIcon size={17} />} label="AQI" value={`${current.aqi ?? '—'} · ${getAqiLabel(current.aqi)}`} />
            <MetricTile icon={<SunriseIcon size={17} />} label="Sunrise" value={formatClock(current.sunrise)} />
            <MetricTile icon={<SunsetIcon size={17} />} label="Sunset" value={formatClock(current.sunset)} />
            <MetricTile icon={<ThermometerIcon size={17} />} label="Dew Point" value={formatTemperature(current.dewPoint, unit)} />
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-6">
        <h3 className="text-sm font-semibold mb-4">Hourly Forecast</h3>
        <HourlyStrip hours={hourly} unit={unit} limit={24} />
      </GlassCard>

      <GlassCard className="p-6">
        <h3 className="text-sm font-semibold mb-2">7-Day Forecast</h3>
        <DailyList days={daily} unit={unit} hourly={hourly} />
      </GlassCard>

      <p className="text-[11px] text-[var(--text-tertiary)] text-right footnote-legible">
        Last updated: {formatLastUpdated(current.lastUpdated)} · Data by Open-Meteo
      </p>
    </div>
  )
}
