/**
 * Thin promise-based wrapper around chrome.storage.local so the rest of
 * the app never touches the callback-style API directly. Falls back to
 * an in-memory map when `chrome` isn't available (e.g. plain `vite dev`
 * in a regular browser tab while iterating on UI).
 */

const memoryFallback = new Map<string, unknown>()
const hasChromeStorage = typeof chrome !== 'undefined' && !!chrome.storage?.local

export async function storageGet<T>(key: string, fallback: T): Promise<T> {
  if (!hasChromeStorage) {
    return (memoryFallback.has(key) ? memoryFallback.get(key) : fallback) as T
  }
  const result = await chrome.storage.local.get(key)
  return (key in result ? result[key] : fallback) as T
}

export async function storageSet<T>(key: string, value: T): Promise<void> {
  if (!hasChromeStorage) {
    memoryFallback.set(key, value)
    return
  }
  await chrome.storage.local.set({ [key]: value })
}

export function onStorageChange(
  callback: (changes: { [key: string]: chrome.storage.StorageChange }) => void
): () => void {
  if (!hasChromeStorage) return () => {}
  const listener = (
    changes: { [key: string]: chrome.storage.StorageChange },
    areaName: string
  ) => {
    if (areaName === 'local') callback(changes)
  }
  chrome.storage.onChanged.addListener(listener)
  return () => chrome.storage.onChanged.removeListener(listener)
}
