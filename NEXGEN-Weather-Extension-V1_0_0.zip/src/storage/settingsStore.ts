import { DEFAULT_SETTINGS, type AppSettings } from '@/types/settings'
import { storageGet, storageSet } from './chromeStorage'

const SETTINGS_KEY = 'nexgen.settings'

export async function loadSettings(): Promise<AppSettings> {
  const stored = await storageGet<Partial<AppSettings>>(SETTINGS_KEY, {})
  return { ...DEFAULT_SETTINGS, ...stored }
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  await storageSet(SETTINGS_KEY, settings)
}

export { SETTINGS_KEY }
