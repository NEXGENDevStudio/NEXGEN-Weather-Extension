import type { SavedLocation } from '@/types/weather'
import { storageGet, storageSet } from './chromeStorage'

const LOCATIONS_KEY = 'nexgen.locations'
const ACTIVE_LOCATION_KEY = 'nexgen.activeLocationId'

const DEFAULT_LOCATION: SavedLocation = {
  id: 'islamabad-pk',
  name: 'Islamabad',
  admin1: 'Islamabad Capital Territory',
  country: 'Pakistan',
  latitude: 33.6844,
  longitude: 73.0479,
  isFavorite: true,
  isCurrent: true
}

export async function loadLocations(): Promise<SavedLocation[]> {
  const stored = await storageGet<SavedLocation[]>(LOCATIONS_KEY, [])
  return stored.length > 0 ? stored : [DEFAULT_LOCATION]
}

export async function saveLocations(locations: SavedLocation[]): Promise<void> {
  await storageSet(LOCATIONS_KEY, locations)
}

export async function loadActiveLocationId(): Promise<string> {
  return storageGet<string>(ACTIVE_LOCATION_KEY, DEFAULT_LOCATION.id)
}

export async function saveActiveLocationId(id: string): Promise<void> {
  await storageSet(ACTIVE_LOCATION_KEY, id)
}

export { DEFAULT_LOCATION, LOCATIONS_KEY, ACTIVE_LOCATION_KEY }
