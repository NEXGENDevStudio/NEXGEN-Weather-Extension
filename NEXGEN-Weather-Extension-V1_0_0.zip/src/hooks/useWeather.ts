import { useCallback, useEffect, useRef, useState } from 'react'
import type { RefreshInterval, SavedLocation, WeatherSnapshot } from '@/types/weather'
import { fetchWeatherSnapshot } from '@/services/openMeteoApi'

interface UseWeatherResult {
  snapshot: WeatherSnapshot | null
  isLoading: boolean
  error: string | null
  refresh: () => Promise<void>
}

/** Fetches (and optionally auto-refreshes) a weather snapshot for a location. */
export function useWeather(location: SavedLocation | undefined, refreshInterval: RefreshInterval): UseWeatherResult {
  const [snapshot, setSnapshot] = useState<WeatherSnapshot | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const requestId = useRef(0)

  const refresh = useCallback(async () => {
    if (!location) return
    const currentRequest = ++requestId.current
    setIsLoading(true)
    setError(null)
    try {
      const result = await fetchWeatherSnapshot(location)
      if (currentRequest === requestId.current) {
        setSnapshot(result)
      }
    } catch (err) {
      if (currentRequest === requestId.current) {
        setError(err instanceof Error ? err.message : 'Failed to load weather data')
      }
    } finally {
      if (currentRequest === requestId.current) setIsLoading(false)
    }
  }, [location])

  useEffect(() => {
    refresh()
  }, [refresh])

  useEffect(() => {
    if (!refreshInterval) return
    const ms = refreshInterval * 60 * 1000
    const id = window.setInterval(refresh, ms)
    return () => window.clearInterval(id)
  }, [refresh, refreshInterval])

  return { snapshot, isLoading, error, refresh }
}
