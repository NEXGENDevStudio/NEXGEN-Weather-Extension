import { useEffect } from 'react'
import type { ThemeMode } from '@/types/weather'

/**
 * Applies the `dark` class to <html> based on the chosen theme mode.
 * 'auto' follows the OS-level prefers-color-scheme and stays live if the
 * user flips their system theme while the popup is open.
 */
export function useTheme(mode: ThemeMode) {
  useEffect(() => {
    const root = document.documentElement
    const mq = window.matchMedia('(prefers-color-scheme: dark)')

    const apply = () => {
      const isDark = mode === 'dark' || (mode === 'auto' && mq.matches)
      root.classList.toggle('dark', isDark)
    }

    apply()
    if (mode === 'auto') {
      mq.addEventListener('change', apply)
      return () => mq.removeEventListener('change', apply)
    }
  }, [mode])
}
