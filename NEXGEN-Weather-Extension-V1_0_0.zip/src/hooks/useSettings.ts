import { useCallback, useEffect, useState } from 'react'
import { DEFAULT_SETTINGS, type AppSettings } from '@/types/settings'
import { loadSettings, saveSettings } from '@/storage/settingsStore'
import { onStorageChange } from '@/storage/chromeStorage'

export function useSettings() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    loadSettings().then((s) => {
      setSettings(s)
      setLoaded(true)
    })
    return onStorageChange((changes) => {
      if (changes['nexgen.settings']) {
        setSettings({ ...DEFAULT_SETTINGS, ...changes['nexgen.settings'].newValue })
      }
    })
  }, [])

  const update = useCallback(async (patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch }
      saveSettings(next)
      return next
    })
  }, [])

  return { settings, updateSettings: update, loaded }
}
