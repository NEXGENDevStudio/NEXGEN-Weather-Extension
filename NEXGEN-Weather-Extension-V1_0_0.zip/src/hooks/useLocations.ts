import { useCallback, useEffect, useState } from 'react'
import type { SavedLocation } from '@/types/weather'
import {
  ACTIVE_LOCATION_KEY,
  LOCATIONS_KEY,
  loadActiveLocationId,
  loadLocations,
  saveActiveLocationId,
  saveLocations
} from '@/storage/locationsStore'
import { onStorageChange } from '@/storage/chromeStorage'

export function useLocations() {
  const [locations, setLocations] = useState<SavedLocation[]>([])
  const [activeId, setActiveId] = useState<string>('')
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    Promise.all([loadLocations(), loadActiveLocationId()]).then(([locs, active]) => {
      setLocations(locs)
      setActiveId(active || locs[0]?.id)
      setLoaded(true)
    })
    // Popup, Dashboard and Side Panel are separate documents — without this,
    // a location change made in one wouldn't reach the others until reload.
    return onStorageChange((changes) => {
      if (changes[LOCATIONS_KEY]) {
        setLocations(changes[LOCATIONS_KEY].newValue ?? [])
      }
      if (changes[ACTIVE_LOCATION_KEY]) {
        setActiveId(changes[ACTIVE_LOCATION_KEY].newValue ?? '')
      }
    })
  }, [])

  const activeLocation = locations.find((l) => l.id === activeId) ?? locations[0]

  const selectLocation = useCallback(async (id: string) => {
    setActiveId(id)
    await saveActiveLocationId(id)
  }, [])

  const addLocation = useCallback(async (location: SavedLocation) => {
    setLocations((prev) => {
      if (prev.some((l) => l.id === location.id)) return prev
      const next = [...prev, location]
      saveLocations(next)
      return next
    })
    await saveActiveLocationId(location.id)
    setActiveId(location.id)
  }, [])

  const removeLocation = useCallback(async (id: string) => {
    setLocations((prev) => {
      const next = prev.filter((l) => l.id !== id)
      const fallback = next.find((l) => l.isFavorite) ?? next[0]
      saveLocations(next)
      if (fallback) {
        setActiveId(fallback.id)
        void saveActiveLocationId(fallback.id)
      } else {
        setActiveId('')
        void saveActiveLocationId('')
      }
      return next
    })
  }, [])

  const toggleFavorite = useCallback(async (id: string) => {
    setLocations((prev) => {
      const next = prev.map((l) => (l.id === id ? { ...l, isFavorite: !l.isFavorite } : l))
      saveLocations(next)
      return next
    })
  }, [])

  return { locations, activeLocation, loaded, selectLocation, addLocation, removeLocation, toggleFavorite }
}
