import type { AppSettings } from '@/types/settings'
import type { WeatherSnapshot } from '@/types/weather'
import { getAqiLabel, getUvLabel, getWeatherCondition, getWeatherLabel } from '@/services/weatherCodeMap'
import { formatLastUpdated, formatPercent, formatTemperature, formatWind, formatClock } from '@/utils/formatters'
import { WeatherIcon } from '@/components/WeatherIcon'
import { GlassCard } from '@/components/GlassCard'
import { HourlyStrip } from '@/components/HourlyStrip'
import { MetricTile } from '@/components/MetricTile'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import {
  DropletIcon,
  EyeIcon,
  GaugeIcon,
  LeafIcon,
  SunIcon,
  SunriseIcon,
  SunsetIcon,
  ThermometerIcon,
  WindIcon
} from '@/components/Icons'

interface Props {
  snapshot: WeatherSnapshot | null
  isLoading: boolean
  error: string | null
  settings: AppSettings
}

export function WeatherView({ snapshot, isLoading, error, settings }: Props) {
  if (!snapshot && isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <LoadingSpinner size={32} />
      </div>
    )
  }

  if (!snapshot) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-2 px-6 text-center">
        <p className="text-sm text-[var(--text-secondary)]">
          {error ?? 'No weather data yet.'}
        </p>
      </div>
    )
  }

  const { current, hourly, daily, location } = snapshot
  const condition = getWeatherCondition(current.weatherCode, current.isDay)

  return (
    <div className="flex-1 overflow-y-auto px-4 pb-4 flex flex-col gap-2.5">
      {/* Hero: icon, temperature, condition */}
      <div className="flex items-center justify-between px-1 animate-fadeIn">
        <div>
          <div className="flex items-start gap-1">
            <span className="text-[64px] leading-none font-thin tracking-tighter">
              {formatTemperature(current.temperature, settings.temperatureUnit).replace('°', '')}
            </span>
            <span className="text-2xl font-light mt-1.5">°{settings.temperatureUnit === 'fahrenheit' ? 'F' : 'C'}</span>
          </div>
          <p className="text-[17px] font-medium mt-1">{getWeatherLabel(current.weatherCode)}</p>
          <p className="text-[13px] text-[var(--text-secondary)]">
            Feels like {formatTemperature(current.feelsLike, settings.temperatureUnit)}
          </p>
        </div>
        <WeatherIcon condition={condition} size={92} className="drop-shadow-lg animate-floatY" />
      </div>

      {/* Sunrise / Sunset / Pressure / Visibility / Dew point */}
      <GlassCard className="p-3.5" delay={40}>
        <div className="grid grid-cols-2 gap-y-3 gap-x-2">
          <MetricTile icon={<SunriseIcon size={17} />} label="Sunrise" value={formatClock(current.sunrise)} />
          <MetricTile icon={<SunsetIcon size={17} />} label="Sunset" value={formatClock(current.sunset)} />
          <div className="col-span-2 hairline-divider" />
          <MetricTile icon={<GaugeIcon size={17} />} label="Pressure" value={`${Math.round(current.pressure)} hPa`} />
          <MetricTile icon={<EyeIcon size={17} />} label="Visibility" value={`${current.visibility} km`} />
          <MetricTile icon={<ThermometerIcon size={17} />} label="Dew Point" value={formatTemperature(current.dewPoint, settings.temperatureUnit)} />
        </div>
      </GlassCard>

      {/* AQI / Humidity / Wind / UV quick row */}
      <div className="grid grid-cols-2 gap-2.5" style={{ animationDelay: '80ms' }}>
        <GlassCard className="p-3 flex items-center gap-2" delay={80}>
          <LeafIcon size={16} className="text-emerald-600 dark:text-emerald-300" />
          <div>
            <div className="text-[11px] text-[var(--text-secondary)] leading-tight">AQI {current.aqi ?? '—'}</div>
            <div className="text-[12px] font-medium leading-tight">{getAqiLabel(current.aqi)}</div>
          </div>
        </GlassCard>
        <GlassCard className="p-3 flex items-center gap-2" delay={100}>
          <DropletIcon size={16} className="text-sky-600 dark:text-sky-300" />
          <div>
            <div className="text-[11px] text-[var(--text-secondary)] leading-tight">Humidity</div>
            <div className="text-[12px] font-medium leading-tight">{formatPercent(current.humidity)}</div>
          </div>
        </GlassCard>
        <GlassCard className="p-3 flex items-center gap-2" delay={120}>
          <WindIcon size={16} className="text-slate-500 dark:text-slate-300" />
          <div>
            <div className="text-[11px] text-[var(--text-secondary)] leading-tight">Wind</div>
            <div className="text-[12px] font-medium leading-tight">{formatWind(current.windSpeed)}</div>
          </div>
        </GlassCard>
        <GlassCard className="p-3 flex items-center gap-2" delay={140}>
          <SunIcon size={16} className="text-amber-600 dark:text-amber-300" />
          <div>
            <div className="text-[11px] text-[var(--text-secondary)] leading-tight">UV Index</div>
            <div className="text-[12px] font-medium leading-tight">{getUvLabel(current.uvIndex)}</div>
          </div>
        </GlassCard>
      </div>

      {/* Hourly forecast */}
      <GlassCard className="pt-3 pb-3.5" delay={160}>
        <h3 className="text-[13px] font-semibold px-4 mb-2.5">Hourly Forecast</h3>
        <HourlyStrip hours={hourly} unit={settings.temperatureUnit} />
      </GlassCard>

      <div className="flex items-center justify-between px-1 text-[11px] text-[var(--text-tertiary)] footnote-legible">
        <span>Last updated: {formatLastUpdated(current.lastUpdated)}</span>
        <span>
          Data by{' '}
          <a
            href="https://open-meteo.com"
            target="_blank"
            rel="noreferrer"
            className="text-[var(--link-color)] hover:underline"
          >
            Open-Meteo
          </a>
        </span>
      </div>

      <p className="sr-only">{location.name}</p>
      {daily.length === 0 && null}
    </div>
  )
}
