import { useEffect, useRef, useState } from 'react'
import type { AppSettings } from '@/types/settings'
import type { SavedLocation, TemperatureUnit, ThemeMode } from '@/types/weather'
import { ScreenHeader } from '@/components/ScreenHeader'
import { BellIcon, ChevronDownIcon, ChevronRightIcon, MapPinIcon } from '@/components/Icons'
import { SHOW_TEST_NOTIFICATION_BUTTON } from '@/config'

interface Props {
  settings: AppSettings
  locations: SavedLocation[]
  onBack: () => void
  onUpdate: (patch: Partial<AppSettings>) => void
  onManageLocations: () => void
  /** Fires an immediate native notification via the background worker, for verifying the pipeline. */
  onTestNotification?: () => Promise<{ ok: boolean; error?: string }>
}

const themeOptions: { value: ThemeMode; label: string; glyph: string }[] = [
  { value: 'light', label: 'Light', glyph: '☀' },
  { value: 'dark', label: 'Dark', glyph: '☾' },
  { value: 'auto', label: 'Auto', glyph: '⧉' }
]

const unitOptions: { value: TemperatureUnit; label: string }[] = [
  { value: 'celsius', label: '°C Celsius' },
  { value: 'fahrenheit', label: '°F Fahrenheit' }
]

const PRESET_MINUTES = [15, 30, 60] as const
const MIN_CUSTOM_MINUTES = 1
const MAX_CUSTOM_MINUTES = 1440 // 24h — a sane ceiling for a "weather check" interval

type IntervalMode = 'preset' | 'custom' | 'manual'

function modeFor(minutes: number): IntervalMode {
  if (minutes <= 0) return 'manual'
  if ((PRESET_MINUTES as readonly number[]).includes(minutes)) return 'preset'
  return 'custom'
}

function clampMinutes(value: number): number {
  if (!Number.isFinite(value)) return MIN_CUSTOM_MINUTES
  return Math.min(MAX_CUSTOM_MINUTES, Math.max(MIN_CUSTOM_MINUTES, Math.round(value)))
}

function NotificationIntervalPicker({
  mode,
  value,
  onSelect
}: {
  mode: IntervalMode
  value: number
  onSelect: (value: string) => void
}) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const onPointerDown = (event: PointerEvent) => {
      if (!ref.current?.contains(event.target as Node)) setOpen(false)
    }
    document.addEventListener('pointerdown', onPointerDown)
    return () => document.removeEventListener('pointerdown', onPointerDown)
  }, [open])

  const options = [
    { value: '15', label: '15 Minutes' },
    { value: '30', label: '30 Minutes' },
    { value: '60', label: '1 Hour' },
    { value: 'custom', label: mode === 'custom' ? `Custom · ${value} Minutes` : 'Custom' },
    { value: 'manual', label: 'Manual Only' }
  ]
  const selectedValue = mode === 'preset' ? String(value) : mode
  const selected = options.find((option) => option.value === selectedValue)?.label ?? '30 Minutes'

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Notification interval"
        onClick={() => setOpen((current) => !current)}
        className="glass-card rounded-card w-full px-3.5 py-2.5 flex items-center justify-between gap-3 text-[13px] text-left hover:bg-[var(--hover-overlay)] transition-colors"
      >
        <span>{selected}</span>
        <ChevronDownIcon size={15} className={`text-[var(--text-tertiary)] transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="Notification interval options"
          className="absolute left-0 right-0 top-[calc(100%+6px)] z-50 glass-card rounded-card p-1 shadow-xl animate-fadeIn"
        >
          {options.map((option) => {
            const active = option.value === selectedValue
            return (
              <button
                key={option.value}
                type="button"
                role="option"
                aria-selected={active}
                onClick={() => {
                  onSelect(option.value)
                  setOpen(false)
                }}
                className={`w-full rounded-lg px-3 py-2 text-[12px] text-left transition-colors ${
                  active ? 'bg-[var(--active-overlay)] font-medium' : 'hover:bg-[var(--hover-overlay)]'
                }`}
              >
                {option.label}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}

export function SettingsView({ settings, locations, onBack, onUpdate, onManageLocations, onTestNotification }: Props) {
  const [testingNotification, setTestingNotification] = useState(false)
  const mode = modeFor(settings.refreshInterval)

  // Draft text for the custom-minutes input. Kept separate from the
  // committed setting so the user can freely type/clear the field
  // without every keystroke round-tripping through chrome.storage.
  const [customDraft, setCustomDraft] = useState(
    mode === 'custom' ? String(settings.refreshInterval) : '5'
  )

  // If another surface (popup vs. dashboard) changes the interval while
  // this screen is open, keep the draft in sync with the real value.
  useEffect(() => {
    if (mode === 'custom') setCustomDraft(String(settings.refreshInterval))
  }, [mode, settings.refreshInterval])

  const commitCustomMinutes = (raw: string) => {
    const parsed = clampMinutes(parseInt(raw, 10))
    setCustomDraft(String(parsed))
    onUpdate({ refreshInterval: parsed })
  }

  const handleSelectChange = (value: string) => {
    if (value === 'manual') {
      onUpdate({ refreshInterval: 0 })
    } else if (value === 'custom') {
      onUpdate({ refreshInterval: clampMinutes(parseInt(customDraft, 10)) })
    } else {
      onUpdate({ refreshInterval: Number(value) })
    }
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden animate-fadeIn">
      <ScreenHeader title="Settings" onBack={onBack} />
      <div className="flex-1 overflow-y-auto px-4 pb-4 flex flex-col gap-4">
        {/* Theme */}
        <section>
          <h3 className="text-[12px] font-medium text-[var(--text-secondary)] mb-2">Theme</h3>
          <div className="grid grid-cols-3 gap-2">
            {themeOptions.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => onUpdate({ theme: opt.value })}
                aria-pressed={settings.theme === opt.value}
                className={`glass-card rounded-card py-3 flex flex-col items-center gap-1 text-[12px] transition-colors ${
                  settings.theme === opt.value ? 'ring-2 ring-[var(--link-color)]' : ''
                }`}
              >
                <span className="text-lg leading-none">{opt.glyph}</span>
                {opt.label}
              </button>
            ))}
          </div>
        </section>

        {/* Temperature unit */}
        <section>
          <h3 className="text-[12px] font-medium text-[var(--text-secondary)] mb-2">Temperature Unit</h3>
          <div className="grid grid-cols-2 gap-2">
            {unitOptions.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => onUpdate({ temperatureUnit: opt.value })}
                aria-pressed={settings.temperatureUnit === opt.value}
                className={`glass-card rounded-card py-2.5 text-[12px] font-medium transition-colors ${
                  settings.temperatureUnit === opt.value ? 'ring-2 ring-[var(--link-color)]' : ''
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </section>

        {/* Notification interval */}
        <section>
          <h3 className="text-[12px] font-medium text-[var(--text-secondary)] mb-2">Notification Interval</h3>
          <NotificationIntervalPicker mode={mode} value={settings.refreshInterval} onSelect={handleSelectChange} />

          {mode === 'custom' && (
            <div className="glass-card rounded-card px-3.5 py-2.5 mt-2 flex items-center gap-2.5">
              <label htmlFor="custom-interval" className="text-[12px] text-[var(--text-secondary)] shrink-0">
                Every
              </label>
              <input
                id="custom-interval"
                type="number"
                inputMode="numeric"
                min={MIN_CUSTOM_MINUTES}
                max={MAX_CUSTOM_MINUTES}
                value={customDraft}
                onChange={(e) => setCustomDraft(e.target.value)}
                onBlur={(e) => commitCustomMinutes(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') e.currentTarget.blur()
                }}
                className="w-16 bg-transparent border border-[var(--divider-color)] rounded-md px-2 py-1 text-[13px] text-center outline-none focus-visible:ring-2 focus-visible:ring-[var(--link-color)]"
              />
              <span className="text-[12px] text-[var(--text-secondary)]">minutes</span>
            </div>
          )}

          <p className="text-[11px] text-[var(--text-tertiary)] mt-2 px-1">
            {mode === 'manual'
              ? 'Weather only refreshes when you open the popup or tap refresh — no automatic notifications.'
              : mode === 'custom'
                ? 'Minimum 1 minute — Chrome/Brave does not allow browser extensions to schedule background checks faster than that, even for "seconds".'
                : 'Also controls how often the background service worker checks for weather updates.'}
          </p>
        </section>

        {/* Notifications */}
        <section>
          <div className="glass-card rounded-card px-3.5 py-3 flex items-center justify-between gap-3">
            <div>
              <h3 className="text-[13px] font-medium">Notifications</h3>
              <p className="text-[11px] text-[var(--text-tertiary)]">
                {settings.notificationsEnabled ? 'On — weather alerts enabled' : 'Off — no automatic alerts'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onUpdate({ notificationsEnabled: !settings.notificationsEnabled })}
              className={`w-11 h-6 rounded-full transition-colors relative shrink-0 focus-visible:ring-2 focus-visible:ring-[var(--link-color)] focus-visible:ring-offset-2 ${
                settings.notificationsEnabled ? 'bg-accent' : 'bg-[var(--toggle-off-bg)]'
              }`}
              role="switch"
              aria-checked={settings.notificationsEnabled}
              aria-label={`Notifications ${settings.notificationsEnabled ? 'on' : 'off'}`}
              title={settings.notificationsEnabled ? 'Disable weather notifications' : 'Enable weather notifications'}
            >
              <span
                aria-hidden="true"
                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-200 ease-out ${
                  settings.notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Dev/QA control — verify the notification pipeline before publishing.
              Hide by setting SHOW_TEST_NOTIFICATION_BUTTON to false in src/config.ts. */}
          {SHOW_TEST_NOTIFICATION_BUTTON && onTestNotification && (
            <button
              type="button"
              onClick={async () => {
                if (!onTestNotification || testingNotification) return
                setTestingNotification(true)
                try {
                  await onTestNotification()
                } finally {
                  setTestingNotification(false)
                }
              }}
              disabled={testingNotification}
              className="w-full mt-2 glass-card rounded-card px-3.5 py-2.5 flex items-center gap-2.5 text-[12px] font-medium hover:bg-[var(--hover-overlay)] transition-colors"
            >
              <BellIcon size={15} className="text-[var(--text-secondary)]" />
              {testingNotification ? 'Testing Notification…' : 'Send Test Notification'}
            </button>
          )}
        </section>

        {/* Manage locations */}
        <section>
          <button
            type="button"
            onClick={onManageLocations}
            className="glass-card rounded-card px-3.5 py-3 flex items-center justify-between w-full"
          >
            <div className="flex items-center gap-2.5">
              <MapPinIcon size={16} className="text-[var(--text-secondary)]" />
              <div className="text-left">
                <h3 className="text-[13px] font-medium">Manage Locations</h3>
                <p className="text-[11px] text-[var(--text-tertiary)]">{locations.length} saved</p>
              </div>
            </div>
            <ChevronRightIcon size={16} className="text-[var(--text-secondary)]" />
          </button>
        </section>
      </div>
    </div>
  )
}
