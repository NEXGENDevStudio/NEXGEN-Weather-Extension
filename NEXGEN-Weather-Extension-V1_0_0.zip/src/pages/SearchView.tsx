import { useEffect, useState } from 'react'
import type { SavedLocation } from '@/types/weather'
import { searchLocations } from '@/services/geocodingApi'
import { ScreenHeader } from '@/components/ScreenHeader'
import { LoadingSpinner } from '@/components/LoadingSpinner'
import { MapPinIcon, SearchIcon, StarIcon, TrashIcon } from '@/components/Icons'

interface Props {
  savedLocations: SavedLocation[]
  activeId: string | undefined
  onBack: () => void
  onSelect: (location: SavedLocation) => void
  onToggleFavorite: (id: string) => void
  onRemove: (id: string) => void
}

export function SearchView({ savedLocations, activeId, onBack, onSelect, onToggleFavorite, onRemove }: Props) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SavedLocation[]>([])
  const [isSearching, setIsSearching] = useState(false)

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([])
      return
    }
    const handle = window.setTimeout(async () => {
      setIsSearching(true)
      try {
        const found = await searchLocations(query)
        setResults(found)
      } catch {
        setResults([])
      } finally {
        setIsSearching(false)
      }
    }, 350)
    return () => window.clearTimeout(handle)
  }, [query])

  const showingSearch = query.trim().length >= 2

  return (
    <div className="flex-1 flex flex-col overflow-hidden animate-fadeIn">
      <ScreenHeader title="Search Location" onBack={onBack} />

      <div className="px-4 pb-3">
        <div className="search-surface flex items-center gap-2 rounded-full px-3.5 py-2.5">
          <SearchIcon size={16} className="text-[var(--text-secondary)]" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search city..."
            className="bg-transparent outline-none text-[13px] flex-1 placeholder:text-[var(--text-tertiary)]"
          />
          {isSearching && <LoadingSpinner size={14} />}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {showingSearch ? (
          <ul className="flex flex-col gap-1">
            {results.map((r) => (
              <li key={r.id}>
                <button
                  type="button"
                  onClick={() => onSelect(r)}
                  className="w-full flex items-center gap-3 px-2.5 py-2.5 rounded-lg hover:bg-[var(--hover-overlay)] transition-colors text-left"
                >
                  <MapPinIcon size={16} className="text-[var(--text-secondary)] shrink-0" />
                  <span className="text-[13px]">
                    {r.name}
                    <span className="text-[var(--text-tertiary)]">
                      {r.admin1 ? `, ${r.admin1}` : ''}, {r.country}
                    </span>
                  </span>
                </button>
              </li>
            ))}
            {!isSearching && results.length === 0 && (
              <p className="text-[13px] text-[var(--text-tertiary)] px-2.5 py-4 text-center">No cities found.</p>
            )}
          </ul>
        ) : (
          <>
            <h3 className="text-[12px] font-medium text-[var(--text-secondary)] px-2.5 mb-1.5 mt-1">Saved Locations</h3>
            <ul className="flex flex-col gap-1">
              {savedLocations.map((loc) => (
                <li key={loc.id} className="group flex items-center gap-1 rounded-lg hover:bg-[var(--hover-overlay)] transition-colors">
                  <button
                    type="button"
                    onClick={() => onSelect(loc)}
                    className="flex-1 flex items-center gap-3 px-2.5 py-2.5 text-left min-w-0"
                  >
                    <MapPinIcon
                      size={16}
                      className={loc.id === activeId ? 'text-[var(--link-color)] shrink-0' : 'text-[var(--text-secondary)] shrink-0'}
                    />
                    <span className="text-[13px] truncate">
                      {loc.name}
                      <span className="text-[var(--text-tertiary)]">, {loc.country}</span>
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(loc.id)}
                    className="icon-btn w-7 h-7 shrink-0"
                    aria-label="Toggle favorite"
                  >
                    <StarIcon size={14} filled={loc.isFavorite} />
                  </button>
                  {(
                    <button
                      type="button"
                      onClick={() => onRemove(loc.id)}
                      className="icon-btn w-7 h-7 mr-1 shrink-0 opacity-0 group-hover:opacity-100"
                      aria-label="Remove location"
                    >
                      <TrashIcon size={14} />
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  )
}
