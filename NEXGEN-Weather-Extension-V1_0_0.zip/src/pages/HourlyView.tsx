import type { WeatherSnapshot } from '@/types/weather'
import type { TemperatureUnit } from '@/types/weather'
import { getWeatherCondition } from '@/services/weatherCodeMap'
import { formatHour, formatTemperature, formatPercent } from '@/utils/formatters'
import { WeatherIcon } from '@/components/WeatherIcon'
import { ScreenHeader } from '@/components/ScreenHeader'
import { DropletIcon } from '@/components/Icons'

interface Props {
  snapshot: WeatherSnapshot | null
  unit: TemperatureUnit
  onBack: () => void
  hoursToShow?: number
}

export function HourlyView({ snapshot, unit, onBack, hoursToShow = 24 }: Props) {
  const hours = snapshot?.hourly.slice(0, hoursToShow) ?? []

  return (
    <div className="flex-1 flex flex-col overflow-hidden animate-fadeIn">
      <ScreenHeader title="Hourly Forecast" onBack={onBack} />
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <div className="glass-card rounded-card divide-y divide-[var(--divider-color)] overflow-hidden">
          {hours.map((h, i) => (
            <div key={h.time} className="flex items-center gap-3 px-3.5 py-2.5">
              <span className="w-14 text-[13px] font-medium shrink-0">{i === 0 ? 'Now' : formatHour(h.time)}</span>
              <WeatherIcon condition={getWeatherCondition(h.weatherCode, h.isDay)} size={24} />
              <span className="flex items-center gap-1 text-[11px] text-sky-600 dark:text-sky-300 w-12 shrink-0">
                <DropletIcon size={11} />
                {formatPercent(h.precipitationProbability)}
              </span>
              <div className="flex-1" />
              <span className="text-[14px] font-semibold">{formatTemperature(h.temperature, unit)}</span>
            </div>
          ))}
          {hours.length === 0 && (
            <p className="text-[13px] text-[var(--text-tertiary)] px-4 py-8 text-center">No forecast data.</p>
          )}
        </div>
      </div>
    </div>
  )
}
