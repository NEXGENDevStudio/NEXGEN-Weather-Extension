import { CloudIcon, ChevronRightIcon } from '@/components/Icons'
import { ScreenHeader } from '@/components/ScreenHeader'

interface Props {
  onBack: () => void
}

/**
 * Links point to the actual NEXGEN Weather repository and its policy
 * files. GitHub and Developer rows show their destination. Privacy/Terms/
 * License intentionally show ONLY the label — never the raw .md
 * filename — with a chevron indicating "opens externally" instead.
 * No API/provider links live here — Open-Meteo is credited as plain
 * text at the bottom, not as an outbound link, since this screen
 * represents NEXGEN, not the data provider.
 */
const links: { label: string; value?: string; href: string }[] = [
  {
    label: 'GitHub Repository',
    value: 'github.com/NEXGENDevStudio/NEXGEN-Weather-Extension',
    href: 'https://github.com/NEXGENDevStudio/NEXGEN-Weather-Extension'
  },
  {
    label: 'Privacy Policy',
    href: 'https://github.com/NEXGENDevStudio/NEXGEN-Weather-Extension/blob/main/PRIVACY.md'
  },
  {
    label: 'Terms of Service',
    href: 'https://github.com/NEXGENDevStudio/NEXGEN-Weather-Extension/blob/main/TERMS-OF-SERVICE.md'
  },
  {
    label: 'License',
    href: 'https://github.com/NEXGENDevStudio/NEXGEN-Weather-Extension/blob/main/LICENSE.md'
  },
  {
    label: 'Developer',
    value: 'nexgen.devstudio@gmail.com',
    href: 'mailto:nexgen.devstudio@gmail.com'
  }
]

export function AboutView({ onBack }: Props) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden animate-fadeIn">
      <ScreenHeader title="About" onBack={onBack} />
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <div className="glass-card rounded-card p-4 flex items-center gap-3 mb-4">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-sky-300 to-blue-500 flex items-center justify-center shrink-0">
            <CloudIcon size={22} />
          </div>
          <div>
            <h3 className="text-[14px] font-semibold">NEXGEN Weather</h3>
            <p className="text-[11px] text-[var(--text-tertiary)]">Version 1.0.0</p>
          </div>
        </div>

        <p className="text-[13px] text-[var(--text-secondary)] leading-relaxed mb-4">
          Beautiful, fast and accurate weather extension.
          <br />
          Made with NEXGEN Dev Studio
        </p>

        <div className="glass-card rounded-card divide-y divide-[var(--divider-color)] overflow-hidden">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between gap-3 px-3.5 py-2.5 hover:bg-[var(--hover-overlay)] transition-colors"
            >
              <span className="text-[12px] text-[var(--text-secondary)] shrink-0">{link.label}</span>
              {link.value ? (
                <span className="text-[12px] text-[var(--link-color)] truncate text-right">{link.value}</span>
              ) : (
                <ChevronRightIcon size={15} className="text-[var(--text-tertiary)] shrink-0" />
              )}
            </a>
          ))}
        </div>

        <p className="text-[11px] text-[var(--text-tertiary)] text-center mt-4">
          Weather data by Open-Meteo
        </p>
      </div>
    </div>
  )
}
