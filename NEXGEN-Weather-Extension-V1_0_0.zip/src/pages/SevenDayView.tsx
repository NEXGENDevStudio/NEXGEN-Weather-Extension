import type { TemperatureUnit, WeatherSnapshot } from '@/types/weather'
import { ScreenHeader } from '@/components/ScreenHeader'
import { DailyList } from '@/components/DailyList'

interface Props {
  snapshot: WeatherSnapshot | null
  unit: TemperatureUnit
  onBack: () => void
}

export function SevenDayView({ snapshot, unit, onBack }: Props) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden animate-fadeIn">
      <ScreenHeader title="7-Day Forecast" onBack={onBack} />
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <div className="glass-card rounded-card px-3.5 py-1">
          {snapshot ? (
            <DailyList days={snapshot.daily} unit={unit} hourly={snapshot.hourly} compact />
          ) : (
            <p className="text-[13px] text-[var(--text-tertiary)] py-8 text-center">No forecast data.</p>
          )}
        </div>
      </div>
    </div>
  )
}
