/**
 * App-wide config flags.
 *
 * SHOW_TEST_NOTIFICATION_BUTTON: shows a "Test Notification" control in
 * Settings so the chrome.notifications wiring can be verified during
 * development / before store submission. Flip to `false` (or delete the
 * button usage in SettingsView.tsx) before publishing a production build.
 */
export const SHOW_TEST_NOTIFICATION_BUTTON = false
