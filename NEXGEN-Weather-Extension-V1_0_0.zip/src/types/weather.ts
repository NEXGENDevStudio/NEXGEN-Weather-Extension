/**
 * Core domain types for weather data, shared across popup, dashboard,
 * services and storage layers.
 */

export type TemperatureUnit = 'celsius' | 'fahrenheit'
export type ThemeMode = 'light' | 'dark' | 'auto'
/**
 * Minutes between automatic weather checks/notifications. 0 = "Manual
 * Only" (never auto-notify). Any positive integer is valid — 15/30/60
 * are the quick-pick presets, everything else is a user-entered
 * "Custom" value (clamped to 1–1440 in the Settings UI).
 */
export type RefreshInterval = number

/** Coarse condition bucket used to pick the animated background + icon set. */
export type WeatherCondition =
  | 'clear-day'
  | 'clear-night'
  | 'partly-cloudy-day'
  | 'partly-cloudy-night'
  | 'cloudy'
  | 'fog'
  | 'drizzle'
  | 'rain'
  | 'thunderstorm'
  | 'snow'

export interface SavedLocation {
  id: string
  name: string
  admin1?: string
  country: string
  latitude: number
  longitude: number
  isFavorite: boolean
  isCurrent?: boolean
}

export interface HourlyPoint {
  time: string // ISO timestamp
  temperature: number
  weatherCode: number
  isDay: boolean
  precipitationProbability: number
}

export interface DailyPoint {
  date: string // ISO date
  weatherCode: number
  tempMax: number
  tempMin: number
  precipitationProbability: number
  sunrise: string
  sunset: string
}

export interface CurrentWeather {
  temperature: number
  feelsLike: number
  weatherCode: number
  isDay: boolean
  humidity: number
  windSpeed: number
  windDirection: number
  pressure: number
  visibility: number
  uvIndex: number
  dewPoint: number
  aqi: number | null
  sunrise: string
  sunset: string
  lastUpdated: string // ISO timestamp
}

export interface WeatherSnapshot {
  location: SavedLocation
  current: CurrentWeather
  hourly: HourlyPoint[]
  daily: DailyPoint[]
}
