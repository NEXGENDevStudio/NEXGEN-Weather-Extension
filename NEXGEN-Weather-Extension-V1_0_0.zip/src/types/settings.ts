import type { RefreshInterval, TemperatureUnit, ThemeMode } from './weather'

export interface AppSettings {
  theme: ThemeMode
  temperatureUnit: TemperatureUnit
  refreshInterval: RefreshInterval
  notificationsEnabled: boolean
}

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'auto',
  temperatureUnit: 'celsius',
  refreshInterval: 30,
  // Off by default: notifications should be opt-in, and starting ON
  // made the toggle look "already on" the very first time Settings
  // opened, which read as broken. Users flip it on once they've
  // confirmed the Test Notification button actually works.
  notificationsEnabled: false
}
