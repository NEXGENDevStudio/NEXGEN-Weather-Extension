import type { WeatherCondition } from '@/types/weather'

/**
 * Open-Meteo returns WMO weather codes (0-99). This maps each code to a
 * human-readable label and a coarse `WeatherCondition` bucket, which in
 * turn drives which icon and animated background variant is shown.
 */
interface WeatherCodeInfo {
  label: string
  condition: (isDay: boolean) => WeatherCondition
}

const WMO_MAP: Record<number, WeatherCodeInfo> = {
  0: { label: 'Clear Sky', condition: (d) => (d ? 'clear-day' : 'clear-night') },
  1: { label: 'Mainly Clear', condition: (d) => (d ? 'clear-day' : 'clear-night') },
  2: { label: 'Partly Cloudy', condition: (d) => (d ? 'partly-cloudy-day' : 'partly-cloudy-night') },
  3: { label: 'Overcast', condition: () => 'cloudy' },
  45: { label: 'Fog', condition: () => 'fog' },
  48: { label: 'Rime Fog', condition: () => 'fog' },
  51: { label: 'Light Drizzle', condition: () => 'drizzle' },
  53: { label: 'Drizzle', condition: () => 'drizzle' },
  55: { label: 'Dense Drizzle', condition: () => 'drizzle' },
  56: { label: 'Freezing Drizzle', condition: () => 'drizzle' },
  57: { label: 'Dense Freezing Drizzle', condition: () => 'drizzle' },
  61: { label: 'Light Rain', condition: () => 'rain' },
  63: { label: 'Rain', condition: () => 'rain' },
  65: { label: 'Heavy Rain', condition: () => 'rain' },
  66: { label: 'Freezing Rain', condition: () => 'rain' },
  67: { label: 'Heavy Freezing Rain', condition: () => 'rain' },
  71: { label: 'Light Snow', condition: () => 'snow' },
  73: { label: 'Snow', condition: () => 'snow' },
  75: { label: 'Heavy Snow', condition: () => 'snow' },
  77: { label: 'Snow Grains', condition: () => 'snow' },
  80: { label: 'Light Showers', condition: () => 'rain' },
  81: { label: 'Showers', condition: () => 'rain' },
  82: { label: 'Violent Showers', condition: () => 'rain' },
  85: { label: 'Snow Showers', condition: () => 'snow' },
  86: { label: 'Heavy Snow Showers', condition: () => 'snow' },
  95: { label: 'Thunderstorm', condition: () => 'thunderstorm' },
  96: { label: 'Thunderstorm w/ Hail', condition: () => 'thunderstorm' },
  99: { label: 'Severe Thunderstorm', condition: () => 'thunderstorm' }
}

export function getWeatherLabel(code: number): string {
  return WMO_MAP[code]?.label ?? 'Unknown'
}

export function getWeatherCondition(code: number, isDay: boolean): WeatherCondition {
  return WMO_MAP[code]?.condition(isDay) ?? (isDay ? 'clear-day' : 'clear-night')
}

/** Simple UV index descriptor, used next to the numeric value. */
export function getUvLabel(uv: number): string {
  if (uv < 3) return 'Low'
  if (uv < 6) return 'Moderate'
  if (uv < 8) return 'High'
  if (uv < 11) return 'Very High'
  return 'Extreme'
}

/** US EPA-style AQI descriptor for the small AQI pill. */
export function getAqiLabel(aqi: number | null): string {
  if (aqi === null) return '—'
  if (aqi <= 50) return 'Good'
  if (aqi <= 100) return 'Moderate'
  if (aqi <= 150) return 'Unhealthy (SG)'
  if (aqi <= 200) return 'Unhealthy'
  if (aqi <= 300) return 'Very Unhealthy'
  return 'Hazardous'
}

/**
 * Flags genuinely extreme temperatures (checked against the raw Celsius
 * value from the API, regardless of the user's display unit) so
 * notifications can swap the usual condition label + "feels like" line
 * for a short safety advisory instead. Returns null for ordinary
 * conditions, where the caller should fall back to the normal weather
 * label.
 */
export function getExtremeTemperatureAdvisory(temperatureCelsius: number): { label: string; advisory: string } | null {
  if (temperatureCelsius >= 40) {
    return { label: 'Extreme Heat', advisory: 'Stay indoors, hydrate often, and avoid direct sun.' }
  }
  if (temperatureCelsius >= 38) {
    return { label: 'Very Hot', advisory: 'Stay hydrated and avoid prolonged outdoor exposure.' }
  }
  if (temperatureCelsius <= -10) {
    return { label: 'Extreme Cold', advisory: 'Bundle up and limit time outdoors.' }
  }
  if (temperatureCelsius <= 0) {
    return { label: 'Very Cold', advisory: 'Dress warmly — freezing conditions.' }
  }
  return null
}
