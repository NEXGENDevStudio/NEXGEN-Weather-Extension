import type { CurrentWeather, DailyPoint, HourlyPoint, SavedLocation, WeatherSnapshot } from '@/types/weather'

/**
 * Open-Meteo integration.
 *
 * Why Open-Meteo: it's free, keyless, has no request quota for personal
 * use, and exposes current conditions + hourly + 7-day + air quality in
 * a single family of endpoints — ideal for a lightweight extension that
 * must not ship or manage an API key. If you later want severe-weather
 * alerts with official wording, pair this with a national met service
 * API for your primary market; Open-Meteo does not provide text alerts.
 */

const FORECAST_BASE = 'https://api.open-meteo.com/v1/forecast'
const AIR_QUALITY_BASE = 'https://air-quality-api.open-meteo.com/v1/air-quality'

interface OpenMeteoResponse {
  current: {
    temperature_2m: number
    apparent_temperature: number
    relative_humidity_2m: number
    weather_code: number
    is_day: number
    wind_speed_10m: number
    wind_direction_10m: number
    surface_pressure: number
    visibility?: number
    dew_point_2m: number
  }
  hourly: {
    time: string[]
    temperature_2m: number[]
    weather_code: number[]
    is_day: number[]
    precipitation_probability: number[]
    uv_index: number[]
  }
  daily: {
    time: string[]
    weather_code: number[]
    temperature_2m_max: number[]
    temperature_2m_min: number[]
    precipitation_probability_max: number[]
    sunrise: string[]
    sunset: string[]
  }
}

async function fetchAqi(lat: number, lon: number): Promise<number | null> {
  try {
    const url = `${AIR_QUALITY_BASE}?latitude=${lat}&longitude=${lon}&current=us_aqi`
    const res = await fetch(url)
    if (!res.ok) return null
    const data = await res.json()
    return typeof data?.current?.us_aqi === 'number' ? Math.round(data.current.us_aqi) : null
  } catch {
    return null
  }
}

export async function fetchWeatherSnapshot(location: SavedLocation): Promise<WeatherSnapshot> {
  const params = new URLSearchParams({
    latitude: String(location.latitude),
    longitude: String(location.longitude),
    current: [
      'temperature_2m',
      'apparent_temperature',
      'relative_humidity_2m',
      'weather_code',
      'is_day',
      'wind_speed_10m',
      'wind_direction_10m',
      'surface_pressure',
      'dew_point_2m'
    ].join(','),
    hourly: [
      'temperature_2m',
      'weather_code',
      'is_day',
      'precipitation_probability',
      'uv_index'
    ].join(','),
    daily: [
      'weather_code',
      'temperature_2m_max',
      'temperature_2m_min',
      'precipitation_probability_max',
      'sunrise',
      'sunset'
    ].join(','),
    timezone: 'auto',
    forecast_days: '7'
  })

  const [weatherRes, aqi] = await Promise.all([
    fetch(`${FORECAST_BASE}?${params.toString()}`),
    fetchAqi(location.latitude, location.longitude)
  ])

  if (!weatherRes.ok) {
    throw new Error(`Open-Meteo request failed with status ${weatherRes.status}`)
  }

  const data = (await weatherRes.json()) as OpenMeteoResponse

  const nowIndex = findClosestHourIndex(data.hourly.time)
  const uvNow = data.hourly.uv_index?.[nowIndex] ?? 0

  const current: CurrentWeather = {
    temperature: data.current.temperature_2m,
    feelsLike: data.current.apparent_temperature,
    weatherCode: data.current.weather_code,
    isDay: data.current.is_day === 1,
    humidity: data.current.relative_humidity_2m,
    windSpeed: data.current.wind_speed_10m,
    windDirection: data.current.wind_direction_10m,
    pressure: data.current.surface_pressure,
    visibility: data.current.visibility ? Math.round(data.current.visibility / 1000) : 10,
    uvIndex: uvNow,
    dewPoint: data.current.dew_point_2m,
    aqi,
    sunrise: data.daily.sunrise[0],
    sunset: data.daily.sunset[0],
    lastUpdated: new Date().toISOString()
  }

  const hourly: HourlyPoint[] = data.hourly.time.map((time, i) => ({
    time,
    temperature: data.hourly.temperature_2m[i],
    weatherCode: data.hourly.weather_code[i],
    isDay: data.hourly.is_day[i] === 1,
    precipitationProbability: data.hourly.precipitation_probability[i] ?? 0
  }))

  const daily: DailyPoint[] = data.daily.time.map((date, i) => ({
    date,
    weatherCode: data.daily.weather_code[i],
    tempMax: data.daily.temperature_2m_max[i],
    tempMin: data.daily.temperature_2m_min[i],
    precipitationProbability: data.daily.precipitation_probability_max[i] ?? 0,
    sunrise: data.daily.sunrise[i],
    sunset: data.daily.sunset[i]
  }))

  return { location, current, hourly, daily }
}

function findClosestHourIndex(times: string[]): number {
  const now = Date.now()
  let best = 0
  let bestDiff = Infinity
  times.forEach((t, i) => {
    const diff = Math.abs(new Date(t).getTime() - now)
    if (diff < bestDiff) {
      bestDiff = diff
      best = i
    }
  })
  return best
}
