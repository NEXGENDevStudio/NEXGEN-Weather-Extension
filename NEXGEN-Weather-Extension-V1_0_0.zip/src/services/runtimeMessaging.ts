/**
 * Thin wrapper around chrome.runtime.sendMessage for the popup/dashboard
 * UI to talk to the background service worker. Kept isolated so UI
 * components never touch chrome.runtime directly.
 */

export type RuntimeMessage = { type: 'TEST_NOTIFICATION' } | { type: 'REFRESH_NOW' }

export async function sendRuntimeMessage(message: RuntimeMessage): Promise<{ ok: boolean; error?: string }> {
  if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
    return { ok: false, error: 'Not running inside an extension context.' }
  }
  try {
    const response = await chrome.runtime.sendMessage(message)
    return response ?? { ok: true }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : 'Message failed' }
  }
}

/** Fires an immediate test notification via the background service worker. */
export function requestTestNotification() {
  return sendRuntimeMessage({ type: 'TEST_NOTIFICATION' })
}
