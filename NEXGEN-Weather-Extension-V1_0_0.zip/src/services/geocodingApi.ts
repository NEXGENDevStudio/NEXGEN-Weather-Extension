import type { SavedLocation } from '@/types/weather'

const GEOCODING_BASE = 'https://geocoding-api.open-meteo.com/v1/search'

interface GeocodingResult {
  id: number
  name: string
  latitude: number
  longitude: number
  country: string
  admin1?: string
}

/** Searches for cities by free-text name using Open-Meteo's geocoding API. */
export async function searchLocations(query: string): Promise<SavedLocation[]> {
  const trimmed = query.trim()
  if (trimmed.length < 2) return []

  const params = new URLSearchParams({ name: trimmed, count: '8', language: 'en', format: 'json' })
  const res = await fetch(`${GEOCODING_BASE}?${params.toString()}`)
  if (!res.ok) throw new Error(`Geocoding request failed with status ${res.status}`)

  const data = (await res.json()) as { results?: GeocodingResult[] }
  return (data.results ?? []).map((r) => ({
    id: `${r.id}`,
    name: r.name,
    admin1: r.admin1,
    country: r.country,
    latitude: r.latitude,
    longitude: r.longitude,
    isFavorite: false
  }))
}
