/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./popup.html', './dashboard.html', './sidepanel.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        glass: {
          light: 'rgba(255, 255, 255, 0.14)',
          border: 'rgba(255, 255, 255, 0.22)',
          dark: 'rgba(15, 23, 42, 0.35)'
        },
        accent: {
          DEFAULT: '#4fc3f7',
          soft: '#8ecae6'
        }
      },
      backdropBlur: {
        xs: '2px',
        glass: '18px'
      },
      borderRadius: {
        xl2: '1.25rem',
        card: '1rem'
      },
      boxShadow: {
        glass: '0 8px 32px 0 rgba(0, 0, 0, 0.28)',
        glow: '0 0 24px 0 rgba(79, 195, 247, 0.35)'
      },
      keyframes: {
        fadeIn: { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        scaleIn: { '0%': { opacity: 0, transform: 'scale(0.96)' }, '100%': { opacity: 1, transform: 'scale(1)' } },
        floatY: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-6px)' } },
        drift: { '0%': { transform: 'translateX(-10%)' }, '100%': { transform: 'translateX(110%)' } },
        rainFall: { '0%': { backgroundPosition: '0 0' }, '100%': { backgroundPosition: '0 100px' } },
        snowFall: { '0%': { backgroundPosition: '0 0, 0 0' }, '100%': { backgroundPosition: '100px 200px, 50px 100px' } },
        twinkle: { '0%,100%': { opacity: 0.3 }, '50%': { opacity: 1 } },
        ripple: { '0%': { transform: 'scale(0)', opacity: 0.6 }, '100%': { transform: 'scale(2.5)', opacity: 0 } },
        slideUp: { '0%': { opacity: 0, transform: 'translateY(12px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } }
      },
      animation: {
        fadeIn: 'fadeIn 0.28s ease-out',
        scaleIn: 'scaleIn 0.22s cubic-bezier(0.16,1,0.3,1)',
        floatY: 'floatY 4s ease-in-out infinite',
        drift: 'drift 26s linear infinite',
        rainFall: 'rainFall 0.5s linear infinite',
        snowFall: 'snowFall 6s linear infinite',
        twinkle: 'twinkle 2.4s ease-in-out infinite',
        ripple: 'ripple 0.6s ease-out',
        slideUp: 'slideUp 0.3s cubic-bezier(0.16,1,0.3,1) both'
      }
    }
  },
  plugins: []
}
