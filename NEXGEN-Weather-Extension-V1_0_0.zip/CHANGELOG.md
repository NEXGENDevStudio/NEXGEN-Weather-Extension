# Changelog

## 1.0.0

- Final production release.
- Hardened MV3 notification delivery with a self-contained notification icon.
- Removed duplicate-notification suppression so scheduled checks report the latest weather each interval.
- Added themed custom notification-interval picker.
- Cleaned About links and release metadata.


All notable changes to NEXGEN Weather are documented in this file.

## [1.0.0] — Final Initial Release

### Fixed
- Fixed browser notification creation by using the packaged relative icon
  resource required by the Notifications API.
- Finalized About-screen repository and policy links.
- Privacy Policy, Terms of Service, and License labels no longer expose `.md`
  filenames.
- Notification toggle includes a native browser tooltip and accessible state.
- Removed the unused `geolocation` permission from the production manifest.

### Security / Privacy
- Kept only permissions required by the implemented feature set.
- No analytics, advertising, tracking, or NEXGEN account system.
- Local settings and saved locations remain in extension storage.
- Proprietary license added for the compiled extension.

### Features
- Current weather and feels-like temperature.
- Hourly forecast with temperature details.
- 7-day forecast with temperature range bars.
- Search, saved locations, and favorites.
- Light / Dark / Auto themes.
- Celsius / Fahrenheit.
- Configurable refresh interval.
- Optional weather notifications with 15 / 30 / 60 / Custom / Manual Only.
- Full-screen dashboard.
- Dynamic weather backgrounds.
- Open-Meteo weather, geocoding, and air-quality integration.

