# NEXGEN Weather — V1.0.0 Final Fix Report

## Critical fix
The production build previously copied `sidepanel.html` as an unbuilt source HTML page. That file referenced `/src/sidepanel/main.tsx`, which does not exist inside `dist/` after a Vite production build. This caused the browser error:

> This side panel path must exist / Could not read manifest

The fix makes `sidepanel.html` a real Vite HTML entry, so its React code and CSS are bundled into `dist/` just like the popup and dashboard.

## Build cleanup
- Removed the duplicate `rollupOptions.input` definition.
- Removed the obsolete raw side-panel copy step.
- Added `sidepanel.html` to post-build validation.
- Added manifest/path validation for V1.0.0.
- Added a check that the built side-panel HTML contains no `/src/` references.
- Moved the CSS `@import` before Tailwind directives to remove the PostCSS warning.
- Replaced the Vite alias path implementation with Node 22's `import.meta.dirname`.
- Kept the existing notification implementation intact because the notification pipeline was already confirmed working.
- Kept only the permissions currently used by the extension: `storage`, `alarms`, `notifications`, and `sidePanel`.

## Expected production output

After:

```text
npm install
npm run build
```

the `dist/` folder must contain:

```text
manifest.json
popup.html
dashboard.html
sidepanel.html
background/service-worker.js
icons/icon16.png
icons/icon32.png
icons/icon48.png
icons/icon128.png
assets/...
```

The extension should be loaded from **the `dist` folder**, not from the source project root.

## Version

Manifest/package/About remain **V1.0.0**.
