@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo NEXGEN Weather V1.0.0 - Production Build
echo ============================================
echo.

if not exist package.json (
  echo ERROR: package.json not found.
  pause
  exit /b 1
)

echo [1/2] Installing dependencies...
call npm install
if errorlevel 1 (
  echo.
  echo ERROR: npm install failed.
  pause
  exit /b 1
)

echo.
echo [2/2] Building production extension...
call npm run build
if errorlevel 1 (
  echo.
  echo ERROR: npm run build failed.
  pause
  exit /b 1
)

echo.
echo ============================================
echo BUILD SUCCESS
echo ============================================
echo.
echo Load this folder in Chrome/Brave:
echo   %~dp0dist
echo.
echo Do NOT load the source root folder.
echo.
pause
