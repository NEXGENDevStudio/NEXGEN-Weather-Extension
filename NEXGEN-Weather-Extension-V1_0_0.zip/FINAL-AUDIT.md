# NEXGEN Weather V1.0.0 — Side Panel Path Fix

The previous build declared `side_panel.default_path` but did not guarantee that
`sidepanel.html` reached `dist/`. This package fixes that.

- `sidepanel.html` is a real root-level build entry.
- Vite/Rollup is explicitly configured to include it.
- `sidepanel.html` is now a real Vite HTML entry and is bundled into `dist/`; no raw `/src/...` side-panel page is copied into the production package.
- `scripts/verify-extension.mjs` verifies `dist/sidepanel.html`.
- Manifest keeps `side_panel.default_path` exactly `sidepanel.html`.

Run:

    npm ci
    npm run verify

Then load `dist/` as the unpacked extension.

A fresh production build could not be executed in this environment because the
npm registry dependency tree was unavailable.
